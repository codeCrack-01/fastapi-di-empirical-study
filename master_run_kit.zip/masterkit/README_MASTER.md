# Master Run Kit — E1 ReviewGate Grid + Chain-Depth Experiment

## What this is
Runs E1 (ReviewGate 480-cell grid, ~8h) then chain-depth (~1h) in sequence.
After every cell: results copied to USB DATA partition.

## Contents
- `setup_master.sh` — full setup (Fedora Workstation)
- `study_c1_4/` — ReviewGate harness (runner, gen_apps, core_read, routes_read, build_db, k6, requirements.txt)
- `run_matrix_e1.py` — E1 grid runner with USB persistence per cell
- `chain_depth/` — chain-depth experiment (gen + runner + harness)
- `run_master.py` — master orchestrator (E1 then chain-depth)

## Quick start
1. Boot Fedora Workstation from USB.
2. Open a terminal.
3. Run: `bash setup_master.sh`
4. Smoke test: `bash run.sh run_matrix_e1.py --smoke --port0 8900`
5. If smoke passes: run full grid during off-hours.

## Full run (~9 hours)
```bash
bash run.sh run_master.py --port0 8900
```

## IMPORTANT: always use the venv python
Do NOT run with system python (`python3 run_matrix_e1.py`). The venv python has
fastapi and all dependencies. Use `bash run.sh ...` or the full path:
`~/bench_master/.venv/bin/python run_matrix_e1.py ...`

## USB persistence
- After each cell, results are copied to the USB DATA partition (auto-detected).
- Common mount points: /run/liveusb/DATA, /mnt/DATA, /media/*/DATA
- Override with: USB_DATA_DIR=/path/to/DATA
- After the run, ALL results are copied to USB.

## After the run
1. Verify: `sha256sum -c manifest.txt` (on USB)
2. Copy results off the machine.
3. Verify checksums locally before destroying the instance.

## Pre-flight checklist
- [ ] Dedicated machine (no other users)
- [ ] High Performance power plan
- [ ] Defender real-time paused, updates paused
- [ ] All apps closed
- [ ] USB drive plugged in (with DATA partition)
- [ ] Core layout checked (hyperthreading siblings)
- [ ] `sensors` installed for thermal monitoring

## Experiments
- E1: 480 cells (5 arms x 2 models x 4 rates x 12 reps), ~8 hours
- Chain-depth: 60 cells (3 depths x 2 rates x 10 reps), ~1 hour
- Total: ~9 hours

## Arms (E1)
- S1: Direct resolution (no framework DI)
- S2: FastAPI Depends()
- S3: Middleware-managed providers
- S4-DI: dependency-injector container (built once)
- S4-Dishka: Dishka container
- Models: sync, async
- Rates: 600, 700, 800, 900 req/s

## Chain-depth
- Depths: 2, 5, 7 (from corpus: median 2, max 7, 58 repos at 5-7)
- Rates: 600, 900 req/s
- 10 reps per cell
- Tests: does p99 increase with chain depth?

## Monitoring
- No ntfy. Check progress by watching the terminal output or the USB DATA partition.
- After each cell, cells.csv is copied to USB. Check: `ls -la /run/liveusb/DATA/cells.csv`
- After the run, ALL results are copied to USB.