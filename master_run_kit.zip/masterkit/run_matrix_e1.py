#!/usr/bin/env python3
"""run_matrix_e1.py — E1 ReviewGate grid runner with USB persistence (no ntfy).

Wraps study_c1_4/run_matrix.py but adds:
- After each cell: copy cells.csv to the USB DATA partition (if found).
- Takes siblings offline before running (with fallback if no permissions).
- Kills leftover processes on the port before each cell.
- Sets OFFLINE_CORES="" BEFORE importing run_matrix to avoid fatal assertion.

No ntfy. No network dependency. Results persist to USB after every cell.

Usage (from $WORKDIR):
  $WORKDIR/study_c1_4/.venv/bin/python run_matrix_e1.py --main --port0 8900
"""
import os
import sys
from pathlib import Path

# --- Guard: ensure fastapi is available ---
try:
    import fastapi  # noqa: F401
except ImportError:
    _venv_py = Path(__file__).resolve().parent / ".venv" / "bin" / "python"
    print(f"ERROR: fastapi not found in {sys.executable}", file=sys.stderr)
    print(f"", file=sys.stderr)
    print(f"This script must be run with the venv python that has fastapi installed.", file=sys.stderr)
    if _venv_py.exists():
        print(f"", file=sys.stderr)
        print(f"  {_venv_py} {Path(__file__).name} ...", file=sys.stderr)
    else:
        print(f"", file=sys.stderr)
        print(f"  The venv does not exist yet. Run setup first:", file=sys.stderr)
        print(f"  bash setup_master.sh", file=sys.stderr)
    sys.exit(1)

# CRITICAL: set this BEFORE importing run_matrix, which reads it at import time
os.environ["REVIEWGATE_OFFLINE_CORES"] = ""

import argparse
import json
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent / "study_c1_4"
sys.path.insert(0, str(HERE))
import run_matrix as RM

USB_DATA_DIR = os.environ.get("USB_DATA_DIR", "")


def find_usb_data():
    if USB_DATA_DIR and Path(USB_DATA_DIR).is_dir():
        return Path(USB_DATA_DIR)
    candidates = [Path("/run/liveusb/DATA"), Path("/mnt/DATA"), Path("/media/DATA")]
    for base in (Path("/media"), Path("/run/media")):
        if base.is_dir():
            for d in base.iterdir():
                if d.is_dir():
                    for sub in (d, d / "DATA"):
                        if sub.is_dir() and sub.name == "DATA":
                            candidates.append(sub)
                    if (d / "DATA").is_dir():
                        candidates.append(d / "DATA")
    for c in candidates:
        if c.is_dir():
            return c
    return None


def usb_persist(src_path, usb_dir):
    if usb_dir is None or not src_path.exists():
        return False
    try:
        dst = usb_dir / src_path.name
        shutil.copy2(src_path, dst)
        return True
    except Exception as e:
        print(f"  USB persist failed: {e}", file=sys.stderr)
        return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--usb-dir", default=USB_DATA_DIR)
    args, rm_args = ap.parse_known_args()

    usb_dir = Path(args.usb_dir) if args.usb_dir else find_usb_data()
    if usb_dir and usb_dir.is_dir():
        print(f"USB DATA partition: {usb_dir}")
    else:
        print("WARNING: USB DATA partition not found. Results saved locally only.")
        usb_dir = None

    # Take siblings offline first (required before assert_disjoint)
    try:
        import runner as _runner_mod
        offline_state = _runner_mod.take_siblings_offline()
        print(f"offline siblings: {offline_state}", file=sys.stderr)
        if offline_state.get("failed"):
            print(f"WARNING: failed to offline: {offline_state['failed']}", file=sys.stderr)
            print("Setting OFFLINE_CORES='' to skip offline check.", file=sys.stderr)
            os.environ["REVIEWGATE_OFFLINE_CORES"] = ""
            _runner_mod.OFFLINE_CORES = ""
            RM.OFFLINE_CORES = ""
        elif not offline_state.get("changed") and not offline_state.get("already"):
            print("WARNING: no cores taken offline. Setting OFFLINE_CORES=''.", file=sys.stderr)
            os.environ["REVIEWGATE_OFFLINE_CORES"] = ""
            _runner_mod.OFFLINE_CORES = ""
            RM.OFFLINE_CORES = ""
    except Exception as e:
        print(f"WARNING: take_siblings_offline failed: {e}", file=sys.stderr)
        print("Setting OFFLINE_CORES='' to skip offline check.", file=sys.stderr)
        os.environ["REVIEWGATE_OFFLINE_CORES"] = ""
        try:
            import runner as _runner_mod2
            _runner_mod2.OFFLINE_CORES = ""
        except Exception:
            pass
        RM.OFFLINE_CORES = ""

    # Patch start_server to kill processes on port before starting
    import runner as _runner_mod3
    _orig_start_server = _runner_mod3.start_server

    def _patched_start_server(module, port, log):
        if shutil.which("fuser"):
            subprocess.run(["fuser", "-k", f"{port}/tcp"], capture_output=True, timeout=10)
        elif shutil.which("lsof"):
            out = subprocess.run(["lsof", "-t", "-i", f"tcp:{port}"], capture_output=True, text=True)
            for pid in out.stdout.split():
                try:
                    os.kill(int(pid), 9)
                except (ProcessLookupError, ValueError):
                    pass
        subprocess.run(["pkill", "-f", f"uvicorn.*{port}"], capture_output=True, timeout=5)
        time.sleep(3)
        return _orig_start_server(module, port, log)

    _runner_mod3.start_server = _patched_start_server
    RM.start_server = _patched_start_server

    # Monkey-patch run_one_cell to add USB persist after each cell
    original_run_one_cell = RM.run_one_cell

    def patched_run_one_cell(cell, port0, tag):
        row, exc = original_run_one_cell(cell, port0, tag)
        csv_path = (HERE / "results" / tag / "cells.csv")
        if csv_path.exists():
            usb_persist(csv_path, usb_dir)
            print(f"  USB persisted ({csv_path.stat().st_size} bytes)")
        return row, exc

    RM.run_one_cell = patched_run_one_cell

    # Set sys.argv for RM.main() (strip our custom args)
    filtered = [sys.argv[0]]
    skip_next = False
    for a in rm_args:
        if skip_next:
            skip_next = False
            continue
        if a == "--usb-dir":
            skip_next = True
            continue
        filtered.append(a)
    sys.argv = filtered

    rc = RM.main()

    # Final: copy all results to USB
    if usb_dir:
        results_dir = HERE / "results"
        if results_dir.exists():
            for f in results_dir.rglob("*"):
                if f.is_file():
                    rel = f.relative_to(results_dir)
                    dst = usb_dir / "results" / rel
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(f, dst)
            print(f"\nAll results copied to {usb_dir}/results/")

    print(f"\n{'='*60}")
    print(f"E1 complete. rc={rc}")
    print(f"{'='*60}")
    return rc


if __name__ == "__main__":
    raise SystemExit(main())