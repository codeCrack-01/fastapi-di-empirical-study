import http from 'k6/http';
import { check } from 'k6';
import { Trend, Counter } from 'k6/metrics';

const TARGET = __ENV.TARGET_URL || 'http://127.0.0.1:8799';
const RATE = Number(__ENV.RATE || 100);
const WARMUP = Number(__ENV.WARMUP_MS || 1000);
const WINDOW = Number(__ENV.WINDOW_MS || 2000);
const COOLDOWN = Number(__ENV.COOLDOWN_MS || 500);
const PATH = __ENV.TARGET_PATH || '/data';

const reqCounter = new Counter('req_total');

export const options = {
  summaryTrendStats: ['avg', 'min', 'med', 'max', 'p(90)', 'p(95)', 'p(99)'],
  scenarios: {
    steady: {
      executor: 'constant-arrival-rate',
      rate: RATE,
      timeUnit: '1s',
      duration: (WARMUP + WINDOW + COOLDOWN) + 'ms',
      preAllocatedVUs: Math.ceil(RATE * 0.5),
      maxVUs: RATE * 2,
    },
  },
};

export default function () {
  const res = http.get(TARGET + PATH, { timeout: '5s' });
  reqCounter.add(1);
  check(res, { 'status 200': (r) => r.status === 200 });
}

export function handleSummary(data) {
  const m = data.metrics;
  const httpDur = m.http_req_duration;
  const p99 = httpDur ? (httpDur.values['p(99)'] || null) : null;
  const p95 = httpDur ? (httpDur.values['p(95)'] || null) : null;
  const dropped = m.dropped_iterations ? m.dropped_iterations.values.count : 0;
  const totalReqs = m.http_reqs ? m.http_reqs.values.count : 0;
  const fidelity = totalReqs / (RATE * (WINDOW / 1000));

  const summary = {
    window: { p99: p99, p95: p95 },
    load_fidelity: Math.min(fidelity, 1.0),
    dropped_iterations: dropped,
    total_requests: totalReqs,
  };

  const path = __ENV.SUMMARY_FILE || '';
  const out = {};
  if (path) out[path] = JSON.stringify(summary);
  out['stdout'] = JSON.stringify(summary);
  return out;
}
