import http from 'k6/http';
import { check } from 'k6';
import { Trend, Counter } from 'k6/metrics';

const TARGET = __ENV.TARGET_URL || 'http://127.0.0.1:8799';
const RATE = Number(__ENV.RATE || 600);
const WARMUP = Number(__ENV.WARMUP_MS || 10000);
const WINDOW = Number(__ENV.WINDOW_MS || 30000);
const COOLDOWN = Number(__ENV.COOLDOWN_MS || 10000);
const PATH = __ENV.TARGET_PATH || '/data';

const p99trend = new Trend('p99_window', true);
const reqCounter = new Counter('req_total');

export const options = {
  scenarios: {
    steady: {
      executor: 'constant-arrival-rate',
      rate: RATE,
      timeUnit: '1s',
      duration: (WARMUP + WINDOW + COOLDOWN) + 'ms',
      preAllocatedVUs: Math.ceil(RATE * 0.5),
      maxVUs: RATE * 2,
    },
  },
  thresholds: {
    'http_req_failed': ['rate<0.01'],
  },
};

let phase = 'warmup';
let windowStart = WARMUP;
let windowEnd = WARMUP + WINDOW;

export default function () {
  const now = Date.now();
  // We can't easily track global time in k6 default function.
  // Instead, use a simple approach: all requests are measured,
  // and we tag them by phase using a counter.
  const res = http.get(TARGET + PATH, { timeout: '5s' });
  reqCounter.add(1);
  check(res, { 'status 200': (r) => r.status === 200 });
}

export function handleSummary(data) {
  const m = data.metrics;
  const httpDur = m.http_req_duration;
  const p99 = httpDur ? httpDur.values['p(99)'] : null;
  const p95 = httpDur ? httpDur.values['p(95)'] : null;
  const dropped = m.dropped_iterations ? m.dropped_iterations.values.count : 0;
  const totalReqs = m.http_reqs ? m.http_reqs.values.count : 0;
  const fidelity = totalReqs / (RATE * (WINDOW / 1000));

  const out = {
    window: { p99, p95 },
    load_fidelity: Math.min(fidelity, 1.0),
    dropped_iterations: dropped,
    total_requests: totalReqs,
  };
  console.log(JSON.stringify(out));
  return {};
}