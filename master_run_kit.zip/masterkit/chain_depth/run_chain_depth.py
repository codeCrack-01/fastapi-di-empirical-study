#!/usr/bin/env python3
"""run_chain_depth.py — chain-depth experiment runner."""
from __future__ import annotations
import argparse
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
PY = os.environ.get("PYTHON", str(Path(__file__).resolve().parent.parent / "venv" / "bin" / "python"))
K6 = os.environ.get("K6_PATH", shutil.which("k6") or "k6")
HARNESS = Path(os.environ.get("HARNESS", str(HERE / "harness_cd.js")))
PORT = 8799
ROUTE = "/data"
SERVER_CORES = os.environ.get("SERVER_CORES", "0,2,4")
K6_CORES = os.environ.get("K6_CORES", "6")
FAST = os.environ.get("TIER2_FAST", "0") == "1"

WARMUP = 5000 if FAST else 10000
WINDOW = 5000 if FAST else 30000
COOLDOWN = 2000 if FAST else 10000
REPS_DEFAULT = 1 if FAST else 10
RATES = [600, 900]
DEPTHS = [2, 5, 7]

USB_DATA_DIR = os.environ.get("USB_DATA_DIR", "")


def find_usb_data():
    if USB_DATA_DIR and Path(USB_DATA_DIR).is_dir():
        return Path(USB_DATA_DIR)
    candidates = [Path("/run/liveusb/DATA"), Path("/mnt/DATA"), Path("/media/DATA")]
    for base in (Path("/media"), Path("/run/media")):
        if base.is_dir():
            for d in base.iterdir():
                if d.is_dir():
                    for sub in (d, d / "DATA"):
                        if sub.is_dir() and sub.name == "DATA":
                            candidates.append(sub)
                    if (d / "DATA").is_dir():
                        candidates.append(d / "DATA")
    for c in candidates:
        if c.is_dir():
            return c
    return None


def usb_persist(src_path, usb_dir):
    if usb_dir is None or not src_path.exists():
        return False
    try:
        dst = usb_dir / src_path.name
        shutil.copy2(src_path, dst)
        return True
    except Exception as e:
        print(f"  USB persist failed: {e}", file=sys.stderr)
        return False


def boot(port, depth):
    env = {**os.environ, "CHAIN_DEPTH": str(depth)}
    subprocess.run([PY, str(HERE / "gen_chain_depth.py")],
                   cwd=HERE, env=env, check=True, capture_output=True)
    cmd = []
    if shutil.which("taskset"):
        cmd += ["taskset", "-c", SERVER_CORES]
    cmd += [PY, "-m", "uvicorn", "app:app",
            "--host", "127.0.0.1", "--port", str(port),
            "--workers", "1", "--log-level", "warning", "--no-access-log"]
    log = open(f"server_depth{depth}.log", "a")
    pro = subprocess.Popen(cmd, cwd=HERE, env=env, stdout=log, stderr=subprocess.STDOUT)
    deadline = time.time() + 30
    while time.time() < deadline:
        if pro.poll() is not None:
            raise RuntimeError(f"server exited early rc={pro.returncode}")
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/data", timeout=2)
            return pro
        except Exception:
            time.sleep(0.5)
    pro.kill()
    raise RuntimeError("server did not become ready")


def run_k6(rate, port, depth):
    summary_file = HERE / f"cd_summary_{depth}_{rate}_{int(time.time()*1000)}.json"
    env = {
        **os.environ,
        "TARGET_URL": f"http://127.0.0.1:{port}",
        "TARGET_PATH": ROUTE,
        "RATE": str(rate),
        "WARMUP_MS": str(WARMUP),
        "WINDOW_MS": str(WINDOW),
        "COOLDOWN_MS": str(COOLDOWN),
        "SUMMARY_FILE": str(summary_file),
    }
    k6cmd = []
    if shutil.which("taskset"):
        k6cmd += ["taskset", "-c", K6_CORES]
    k6cmd += [K6, "run", str(HARNESS)]
    out = subprocess.run(k6cmd, env=env, capture_output=True, text=True,
                         timeout=WARMUP + WINDOW + COOLDOWN + 60)
    # Read from summary file if it exists
    if summary_file.exists():
        try:
            data = json.loads(summary_file.read_text())
            # Clean up summary file
            summary_file.unlink(missing_ok=True)
            return json.dumps(data)
        except (json.JSONDecodeError, OSError):
            pass
    summary_file.unlink(missing_ok=True)
    return out.stdout + "\n" + out.stderr


def parse_k6(text):
    import json
    # Try parsing as direct JSON first
    text = text.strip()
    if text.startswith("{"):
        try:
            d = json.loads(text)
            return {
                "p99": d.get("window", {}).get("p99"),
                "p95": d.get("window", {}).get("p95"),
                "fidelity": d.get("load_fidelity"),
                "dropped": d.get("dropped_iterations", 0),
            }
        except json.JSONDecodeError:
            pass
    # Fall back to searching lines
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("{") and "load_fidelity" in line:
            try:
                d = json.loads(line)
                return {
                    "p99": d.get("window", {}).get("p99"),
                    "p95": d.get("window", {}).get("p95"),
                    "fidelity": d.get("load_fidelity"),
                    "dropped": d.get("dropped_iterations", 0),
                }
            except json.JSONDecodeError:
                pass
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--depth", type=int, default=None)
    ap.add_argument("--rate", type=int, default=None)
    ap.add_argument("--reps", type=int, default=REPS_DEFAULT)
    ap.add_argument("--port", type=int, default=PORT)
    ap.add_argument("--grid", action="store_true")
    ap.add_argument("--out", default="results_chain_depth.tsv")
    args = ap.parse_args()

    usb_dir = find_usb_data()
    if usb_dir and usb_dir.is_dir():
        print(f"USB DATA partition: {usb_dir}")
    else:
        print("WARNING: USB DATA partition not found. Results saved locally only.")
        usb_dir = None

    depths = [args.depth] if args.depth else DEPTHS
    rates = [args.rate] if args.rate else RATES
    results = []
    for depth in depths:
        for rate in rates:
            for rep in range(args.reps):
                print(f"=== depth={depth} @ {rate} rep {rep+1}/{args.reps} ===", flush=True)
                pro = None
                try:
                    pro = boot(args.port, depth)
                    time.sleep(2)
                    text = run_k6(rate, args.port, depth)
                    parsed = parse_k6(text)
                    p99 = parsed["p99"] if parsed else None
                    fid = parsed["fidelity"] if parsed else None
                    dropped = parsed["dropped"] if parsed else None
                    print(f"  p99={p99} fidelity={fid} dropped={dropped}")
                    results.append({"depth": depth, "rate": rate, "rep": rep + 1,
                                    "p99": p99, "fidelity": fid, "dropped": dropped})
                except Exception as e:
                    print(f"  ERROR: {e}")
                    results.append({"depth": depth, "rate": rate, "rep": rep + 1,
                                    "p99": None, "error": str(e)})
                finally:
                    if pro:
                        pro.kill()
                        pro.wait(timeout=20)
                    time.sleep(3)
                # USB persist after each cell
                if usb_dir:
                    out_path = Path(args.out)
                    if out_path.exists():
                        usb_persist(out_path, usb_dir)

    with open(args.out, "a") as f:
        for r in results:
            f.write(f"{r['depth']}\t{r['rate']}\t{r['rep']}\t{r.get('p99')}\t{r.get('fidelity')}\t{r.get('dropped', 0)}\t{r.get('error', '')}\n")
    print(f"\nResults appended to {args.out}")

    # Final USB copy
    if usb_dir:
        out_path = Path(args.out)
        if out_path.exists():
            usb_persist(out_path, usb_dir)
        print(f"All results copied to {usb_dir}")


if __name__ == "__main__":
    main()
