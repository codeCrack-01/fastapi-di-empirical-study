"""gen_chain_depth.py — generate a minimal FastAPI app with configurable chain depth."""
import os
import sqlite3
from pathlib import Path

DEPTH = int(os.environ.get("CHAIN_DEPTH", "2"))
HERE = Path(__file__).resolve().parent
DB = HERE / "data_cd.db"

if not DB.exists():
    conn = sqlite3.connect(str(DB))
    conn.execute("CREATE TABLE data (id INTEGER PRIMARY KEY, value TEXT)")
    conn.executemany("INSERT INTO data (id, value) VALUES (?, ?)",
                     [(i, f"row-{i}") for i in range(1000)])
    conn.commit()
    conn.close()

lines = []
lines.append('"""Chain-depth experiment app. CHAIN_DEPTH controls depth."""')
lines.append("import sqlite3, os")
lines.append("from fastapi import FastAPI, Depends")
lines.append(f"DB = {repr(str(DB))}")
lines.append(f"DEPTH = {DEPTH}")
lines.append("")
lines.append("def get_db():")
lines.append("    conn = sqlite3.connect(DB)")
lines.append("    rows = conn.execute('SELECT count(*) FROM data').fetchone()")
lines.append("    conn.close()")
lines.append("    return rows[0]")
lines.append("")

for i in range(DEPTH, 0, -1):
    if i == DEPTH:
        lines.append(f"def dep_{i}(db: int = Depends(get_db)):")
        lines.append(f"    return db + 1")
    else:
        lines.append(f"def dep_{i}(prev: int = Depends(dep_{i+1})):")
        lines.append(f"    return prev + 1")
    lines.append("")

lines.append("app = FastAPI()")
lines.append("")
lines.append("@app.get('/data')")
lines.append(f"async def get_data(d: int = Depends(dep_1)):")
lines.append("    return {'count': d}")
lines.append("")

code = "\n".join(lines)
(HERE / "app.py").write_text(code)
print(f"Generated app.py with chain depth {DEPTH}")