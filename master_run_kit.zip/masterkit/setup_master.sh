#!/usr/bin/env bash
# setup_master.sh — complete setup for E1 ReviewGate grid rerun
# Run on a fresh Fedora Workstation.
# Usage: bash setup_master.sh [WORKDIR]
set -euo pipefail

WORKDIR="${1:-$HOME/bench_master}"
mkdir -p "$WORKDIR"
cd "$WORKDIR"

echo "=== 1. System packages ==="
# Try python3.12 first, fall back to python3
if command -v python3.12 &>/dev/null; then
    PYTHON_BIN=python3.12
elif command -v python3.13 &>/dev/null; then
    PYTHON_BIN=python3.13
elif command -v python3.11 &>/dev/null; then
    PYTHON_BIN=python3.11
else
    PYTHON_BIN=python3
fi
echo "Using Python: $PYTHON_BIN ($(command -v $PYTHON_BIN))"
sudo dnf install -y k6 git gcc make lm_sensors psmisc $PYTHON_BIN ${PYTHON_BIN}-devel 2>/dev/null || true

echo "=== 2. Copy experiment files ==="
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp -r "$SCRIPT_DIR/study_c1_4" "$WORKDIR/"
cp "$SCRIPT_DIR/run_matrix_e1.py" "$WORKDIR/"
cp "$SCRIPT_DIR/run_master.py" "$WORKDIR/"
mkdir -p "$WORKDIR/chain_depth"
cp "$SCRIPT_DIR/chain_depth/"* "$WORKDIR/chain_depth/"

echo "=== 3. Python venv (at WORKDIR level) ==="
cd "$WORKDIR"
$PYTHON_BIN -m venv .venv
.venv/bin/pip install --upgrade pip
.venv/bin/pip install -r study_c1_4/requirements.txt
echo "=== Verify fastapi installed ==="
.venv/bin/python -c "import fastapi; print('fastapi', fastapi.__version__)" || { echo "ERROR: fastapi not installed!"; exit 1; }

echo "=== 4. Build the database ==="
cd "$WORKDIR/study_c1_4"
"$WORKDIR/.venv/bin/python" build_db.py 2>&1 | tail -3

echo "=== 5. Prepare box (topology + offline siblings) ==="
# Run as root for topology capture and sibling offlining
sudo "$WORKDIR/.venv/bin/python" prepare_box.py 2>&1 | tail -10 || echo "prepare_box.py failed — run manually: sudo $WORKDIR/.venv/bin/python $WORKDIR/study_c1_4/prepare_box.py"

echo "=== 6. Verify ==="
cd "$WORKDIR"
.venv/bin/python -c "import fastapi, uvicorn, anyio, dependency_injector, dishka; print('all deps ok')" 2>&1 | tail -2
.venv/bin/python study_c1_4/run_matrix.py --dry-run --main 2>&1 | tail -3

echo "=== Setup complete ==="
echo "Repo: $WORKDIR/study_c1_4"
echo "Runner: $WORKDIR/run_matrix_e1.py"
echo "Venv python: $WORKDIR/.venv/bin/python"
echo ""
echo "Smoke test:"
echo "  cd $WORKDIR"
echo "  $WORKDIR/.venv/bin/python run_matrix_e1.py --smoke --port0 8900"
echo ""
echo "Full run (~8 hours):"
echo "  $WORKDIR/.venv/bin/python run_matrix_e1.py --main --port0 8900"
echo ""
echo "USB DATA partition: check /run/liveusb/DATA, /mnt/DATA, /media/*/DATA"
echo "Override with: USB_DATA_DIR=/path/to/DATA"