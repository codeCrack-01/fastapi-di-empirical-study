#!/usr/bin/env python3
"""run_master.py — Master orchestrator: E1 ReviewGate grid, then chain-depth.

Runs E1 first (~8h), then chain-depth (~1h). After every cell:
- Copies results to USB DATA partition (if found).

No ntfy. No network dependency. Results persist to USB after every cell.

Usage (from $WORKDIR):
  $WORKDIR/.venv/bin/python run_master.py --port0 8900
"""
import argparse
import os
import shutil
import subprocess
import sys
import time
import threading
from pathlib import Path

HERE = Path(__file__).resolve().parent
STUDY = HERE / "study_c1_4"
PYTHON = os.environ.get("PYTHON", str(HERE / ".venv" / "bin" / "python"))

USB_DATA_DIR = os.environ.get("USB_DATA_DIR", "")


def find_usb_data():
    if USB_DATA_DIR and Path(USB_DATA_DIR).is_dir():
        return Path(USB_DATA_DIR)
    candidates = [Path("/run/liveusb/DATA"), Path("/mnt/DATA"), Path("/media/DATA")]
    for base in (Path("/media"), Path("/run/media")):
        if base.is_dir():
            for d in base.iterdir():
                if d.is_dir():
                    for sub in (d, d / "DATA"):
                        if sub.is_dir() and sub.name == "DATA":
                            candidates.append(sub)
                    if (d / "DATA").is_dir():
                        candidates.append(d / "DATA")
    for c in candidates:
        if c.is_dir():
            return c
    return None


def usb_persist(src_path, usb_dir):
    if usb_dir is None or not src_path.exists():
        return False
    try:
        dst = usb_dir / src_path.name
        shutil.copy2(src_path, dst)
        return True
    except Exception as e:
        print(f"  USB persist failed: {e}", file=sys.stderr)
        return False


def run_experiment(cmd, label, usb_dir, watch_file):
    print(f"\n{'='*60}")
    print(f"Starting: {label}")
    print(f"Command: {' '.join(cmd)}")
    print(f"{'='*60}\n")

    stop_event = threading.Event()

    def monitor():
        last_size = 0
        last_lines = 0
        while not stop_event.is_set():
            time.sleep(10)
            if watch_file.exists():
                try:
                    sz = watch_file.stat().st_size
                    if sz != last_size:
                        last_size = sz
                        with open(watch_file) as f:
                            lines = sum(1 for _ in f)
                        if lines > last_lines:
                            new_cells = lines - last_lines
                            last_lines = lines
                            usb_persist(watch_file, usb_dir)
                            print(f"{label}: {lines} cells done (+{new_cells})", flush=True)
                except Exception:
                    pass

    mon = threading.Thread(target=monitor, daemon=True)
    mon.start()

    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    for line in proc.stdout:
        print(line, end="", flush=True)
    proc.wait()

    stop_event.set()
    mon.join(timeout=5)

    if usb_dir and watch_file.exists():
        usb_persist(watch_file, usb_dir)
        results_dir = watch_file.parent
        if results_dir.exists():
            for f in results_dir.rglob("*"):
                if f.is_file():
                    rel = f.relative_to(results_dir)
                    dst = usb_dir / "results" / label.replace(" ", "_") / rel
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(f, dst)

    print(f"\n{label} complete. rc={proc.returncode}.")
    return proc.returncode


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port0", type=int, default=8900)
    ap.add_argument("--usb-dir", default=os.environ.get("USB_DATA_DIR", ""))
    ap.add_argument("--skip-e1", action="store_true")
    ap.add_argument("--skip-chain", action="store_true")
    args = ap.parse_args()

    usb_dir = Path(args.usb_dir) if args.usb_dir else find_usb_data()
    if usb_dir and usb_dir.is_dir():
        print(f"USB DATA partition: {usb_dir}")
    else:
        print("WARNING: USB DATA partition not found. Results saved locally only.")
        usb_dir = None

    rc_total = 0

    # Phase 1: E1 ReviewGate grid (~8 hours)
    if not args.skip_e1:
        e1_cmd = [PYTHON, str(HERE / "run_matrix_e1.py"), "--main", "--port0", str(args.port0)]
        if usb_dir:
            e1_cmd += ["--usb-dir", str(usb_dir)]
        e1_watch = STUDY / "results" / "main" / "cells.csv"
        rc = run_experiment(e1_cmd, "E1 ReviewGate grid", usb_dir, e1_watch)
        rc_total = max(rc_total, rc)
        if rc != 0:
            print(f"E1 exited with rc={rc}. Continuing to chain-depth.")

    # Phase 2: Chain-depth (~1 hour)
    if not args.skip_chain:
        cd_dir = HERE / "chain_depth"
        cd_runner = cd_dir / "run_chain_depth.py"
        if not cd_runner.exists():
            print("ERROR: run_chain_depth.py not found. Skipping chain-depth.")
        else:
            cd_cmd = [PYTHON, str(cd_runner), "--grid", "--port", "8799",
                      "--out", str(HERE / "results_chain_depth.tsv")]
            cd_watch = HERE / "results_chain_depth.tsv"
            rc = run_experiment(cd_cmd, "Chain-depth", usb_dir, cd_watch)
            rc_total = max(rc_total, rc)

    print(f"\n{'='*60}")
    print(f"Master run complete. rc={rc_total}")
    print(f"{'='*60}")
    return rc_total


if __name__ == "__main__":
    raise SystemExit(main())