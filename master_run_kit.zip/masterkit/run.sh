#!/usr/bin/env bash
# run.sh — wrapper that ensures the venv python is used
# Usage: bash run.sh run_matrix_e1.py --smoke --port0 8900
#        bash run.sh run_master.py --port0 8900
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_PY="$SCRIPT_DIR/.venv/bin/python"

if [ ! -f "$VENV_PY" ]; then
    echo "ERROR: venv not found at $VENV_PY"
    echo "Run setup first: bash $SCRIPT_DIR/setup_master.sh"
    exit 1
fi

# Verify fastapi is importable
if ! "$VENV_PY" -c "import fastapi" 2>/dev/null; then
    echo "ERROR: fastapi not installed in venv"
    echo "Run: $VENV_PY -m pip install -r $SCRIPT_DIR/study_c1_4/requirements.txt"
    exit 1
fi

exec "$VENV_PY" "$@"