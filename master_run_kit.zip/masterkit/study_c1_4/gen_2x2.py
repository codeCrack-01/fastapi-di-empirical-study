"""gen_2x2.py — render the 2x2 mechanism experiment apps.

Eight variants of a single endpoint (/data) that does a blocking SQLite read
in the getter, so the threadpool actually gets stressed:

  sync-inline      sync getter, called inline (no Depends)  -- bad pattern
  sync-depends     sync getter, via Depends()                -- baseline
  async-inline     async getter, called inline
  async-depends    async getter, via Depends()
  wrapper          sync getter via anyio.to_thread.run_sync
  limiter-200/1000/4000  sync-depends + threadpool limiter N

Run: python gen_2x2.py
"""
from __future__ import annotations
import os, sqlite3, textwrap
from pathlib import Path

HERE = Path(__file__).resolve().parent
APPS = HERE / "apps_2x2"
DB_PATH = HERE / "data_2x2.db"

# Build a small SQLite DB with 1000 rows
def build_db():
    if DB_PATH.exists():
        return
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute("CREATE TABLE data (id INTEGER PRIMARY KEY, value TEXT)")
    conn.executemany("INSERT INTO data (id, value) VALUES (?, ?)",
                     [(i, f"row-{i}") for i in range(1000)])
    conn.commit()
    conn.close()
    print(f"Built {DB_PATH}")

BUILDERS = {}

def make_sync_inline():
    return '''"""2x2: sync getter, inline (no Depends)."""
import sqlite3
from fastapi import FastAPI
from contextlib import asynccontextmanager

DB = "%s"

def get_data():
    conn = sqlite3.connect(DB)
    rows = conn.execute("SELECT count(*) FROM data").fetchone()
    conn.close()
    return rows[0]

app = FastAPI()

@app.get("/data")
async def get_data_endpoint():
    # sync getter called inline in async handler -> blocks event loop
    result = get_data()
    return {"count": result}
''' % DB_PATH

def make_sync_depends():
    return '''"""2x2: sync getter, via Depends()."""
import sqlite3
from fastapi import FastAPI, Depends
from contextlib import asynccontextmanager

DB = "%s"

def get_data():
    conn = sqlite3.connect(DB)
    rows = conn.execute("SELECT count(*) FROM data").fetchone()
    conn.close()
    return rows[0]

app = FastAPI()

@app.get("/data")
async def get_data_endpoint(data: int = Depends(get_data)):
    return {"count": data}
''' % DB_PATH

def make_async_inline():
    return '''"""2x2: async getter, called inline."""
import sqlite3
import asyncio
from fastapi import FastAPI

DB = "%s"

async def get_data():
    # async getter: runs on event loop, no threadpool
    conn = sqlite3.connect(DB)
    rows = conn.execute("SELECT count(*) FROM data").fetchone()
    conn.close()
    return rows[0]

app = FastAPI()

@app.get("/data")
async def get_data_endpoint():
    result = await get_data()
    return {"count": result}
''' % DB_PATH

def make_async_depends():
    return '''"""2x2: async getter, via Depends()."""
import sqlite3
from fastapi import FastAPI, Depends

DB = "%s"

async def get_data():
    conn = sqlite3.connect(DB)
    rows = conn.execute("SELECT count(*) FROM data").fetchone()
    conn.close()
    return rows[0]

app = FastAPI()

@app.get("/data")
async def get_data_endpoint(data: int = Depends(get_data)):
    return {"count": data}
''' % DB_PATH

def make_wrapper():
    return '''"""2x2: sync getter via anyio.to_thread.run_sync."""
import sqlite3
import anyio
from fastapi import FastAPI

DB = "%s"

def get_data():
    conn = sqlite3.connect(DB)
    rows = conn.execute("SELECT count(*) FROM data").fetchone()
    conn.close()
    return rows[0]

app = FastAPI()

@app.get("/data")
async def get_data_endpoint():
    result = await anyio.to_thread.run_sync(get_data)
    return {"count": result}
''' % DB_PATH

def make_limiter(n):
    return '''"""2x2: sync-depends + threadpool limiter %d."""
import sqlite3
import os
import anyio
from fastapi import FastAPI, Depends
from contextlib import asynccontextmanager

DB = "%s"
LIMIT = %d

@asynccontextmanager
async def lifespan(app: FastAPI):
    anyio.to_thread.current_default_thread_limiter().total_tokens = int(os.environ.get("THREAD_LIMIT", str(LIMIT)))
    yield

def get_data():
    conn = sqlite3.connect(DB)
    rows = conn.execute("SELECT count(*) FROM data").fetchone()
    conn.close()
    return rows[0]

app = FastAPI(lifespan=lifespan)

@app.get("/data")
async def get_data_endpoint(data: int = Depends(get_data)):
    return {"count": data}
''' % (n, DB_PATH, n)

BUILDERS = {
    "sync-inline": make_sync_inline,
    "sync-depends": make_sync_depends,
    "async-inline": make_async_inline,
    "async-depends": make_async_depends,
    "wrapper": make_wrapper,
    "limiter-200": lambda: make_limiter(200),
    "limiter-1000": lambda: make_limiter(1000),
    "limiter-4000": lambda: make_limiter(4000),
}

def main():
    build_db()
    APPS.mkdir(parents=True, exist_ok=True)
    for name, builder in BUILDERS.items():
        d = APPS / name
        d.mkdir(parents=True, exist_ok=True)
        (d / "app.py").write_text(builder())
        (d / "__init__.py").write_text("")
        print(f"  built {name}")
    print(f"\nAll {len(BUILDERS)} arms written to {APPS}")

if __name__ == "__main__":
    main()