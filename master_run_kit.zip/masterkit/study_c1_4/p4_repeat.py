import json,os,subprocess,sys,time
sys.path.insert(0,".")
import runner
port=8900; RATE=400
plan=[("p4_container","sync"),("p1_direct","sync"),("p4_container","sync"),
      ("p1_direct","sync"),("p4_container","sync"),("p1_direct","async")]
for i,(pat,mod) in enumerate(plan,1):
    log=runner.HERE/"results"/"cells"/f"rep{i}.server.log"
    sm=runner.HERE/"results"/"cells"/f"rep{i}.summary.json"
    for f in (log,sm): f.unlink(missing_ok=True)
    p=runner.start_server(f"apps.{pat}.{mod}.app:app",port,log)
    try:
        e=runner._env(); e.update({"TARGET_URL":f"http://127.0.0.1:{port}","SCENARIO":"steady",
          "RATE":str(RATE),"WINDOW_MS":"30000","WARMUP_MS":"10000","COOLDOWN_MS":"12000",
          "RAMP_MAX":str(RATE),"RAMP_MS":"8000","SUMMARY_FILE":str(sm)})
        t0=time.time()
        subprocess.run(["taskset","-c",runner.K6_CORES,"k6","run","--quiet","k6/harness.js"],
                       cwd=str(runner.HERE),env=e,capture_output=True,text=True)
        dur=round(time.time()-t0,1)
        d=json.loads(sm.read_text()) if sm.exists() else {}
        h=d.get("http_req_duration") or {}
        print(f"  {i} {pat+'/'+mod:<22} dur={dur:>7}s win_req={d.get('window_requests')} "
              f"iters={d.get('iterations')} max_ms={h.get('max')} fails={d.get('checkFailures')}", flush=True)
    finally:
        p.kill(); time.sleep(1)
print("DONE", flush=True)
