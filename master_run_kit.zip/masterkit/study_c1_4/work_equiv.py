"""work_equiv.py -- do the arms actually do the SAME work?

smoke.py already proves the arms are *observably equivalent*: same route
surface, same status codes, byte-identical bodies. It cannot prove they are
*equivalently loaded*, because an arm can return the right answer while doing a
different amount of work behind it.

This is the check that matters for any claim about what DI costs. An arm
measuring CHEAPER than the no-DI baseline is not physically possible if both do
the same work, so either the arms differ in work, or the CPU measurement is
confounded. This script answers that directly.

WHY IT EXISTS, CONCRETELY. Before Option A, s3_middleware, s4_container and
s4_dishka each opened TWO pooled connections on the six authenticated routes --
one for the role check, one for the service query -- where s1_direct and
s2_depends opened ONE. SQL was identical and responses were byte-identical, so
nothing observable distinguished them. But releasing and re-acquiring shortens
each connection's hold time, and with POOL=8 on 8 cores the pool is the
bottleneck, not the CPU. Those three arms therefore appeared up to 12% FASTER
than doing no DI at all. That result was an artefact of connection hold time,
not a property of dependency resolution.

TWO KINDS OF NUMBER, AND THE DISTINCTION IS THE POINT
----------------------------------------------------
WORK counters must be IDENTICAL across every arm. If they are not, the arms are
not comparable and every latency difference between them is partly a workload
difference. These are gated:

    checkouts      pooled connections leased
    returns        pooled connections returned
    sql            SQL statements executed
    rows           result rows materialised   (real rows, not query count)
    current_user   auth-layer entry points
    lookup_user    auth-layer queries
    require_role   authorisation checks
    service_calls  service-layer calls

MECHANISM counters are EXPECTED to differ -- they are the independent variable,
not a confound. They are reported, never gated:

    hold_ms        total connection hold time (the quantity that explained the
                   old sub-1.0x container results; if it no longer separates the
                   arms, Option A did what it was supposed to)
    bearer_token   header parses (s3 does one per request even when public)
    ctx_objects    per-request context objects constructed

A static, source-level census of RESOLUTION SITES (Depends defaults, provider
calls, injected parameters, generator dependencies) is reported per arm for the
same reason: it is the mechanism being compared, and it is what makes the
mechanism counts interpretable.

Harness invariant: every patch is applied to core_read BEFORE the app module is
imported, because the generated apps do `from core_read import current_user`,
binding the name at import time. Patching afterwards would silently miss the
Depends arm.

Run:  python work_equiv.py
"""

from __future__ import annotations

import ast
import asyncio
import json
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

ARMS = [(p, m) for p in
        ["s1_direct", "s2_depends", "s3_middleware", "s4_container", "s4_dishka"]
        for m in ["sync", "async"]]

# Counters that MUST match across every arm for the comparison to be valid.
WORK_KEYS = ["checkouts", "returns", "sql", "rows",
             "lookup_user", "require_role", "service_calls"]
# Counters that are the mechanism under test; reported, never gated.
#
# current_user is here, not in WORK, because it is a wrapper whose PRESENCE is
# the mechanism: four arms authenticate through current_user(conn, request),
# while s3's middleware authenticates through lookup_user(conn, token) directly
# and applies the suspension rule itself. Both perform exactly one DB-touching
# user lookup, which is what lookup_user counts and what the gate checks.
MECH_KEYS = ["hold_ms", "bearer_token", "ctx_objects", "current_user"]

# core_read's service layer: every async def that takes a connection. All arms
# reach these through the `services` module alias, so patching the module global
# catches both `resolve(services.x(...))` (sync) and `await services.x(...)`.
SERVICE_FNS = [
    "health_check", "list_reviews", "get_review", "search_reviews", "review_stats",
    "list_comments", "me", "list_admins", "export_reviews", "audit_trail",
    "admin_dashboard", "get_config",
]
AUTH_ASYNC_FNS = ["current_user", "lookup_user"]
AUTH_SYNC_FNS = ["require_role", "bearer_token"]

ADMIN = {"Authorization": "Bearer admin-token"}
USER = {"Authorization": "Bearer user-token"}

PROBES = [
    ("/health", {}),
    ("/reviews?limit=20&offset=0", {}),
    ("/reviews/search?q=Review&limit=10", {}),
    ("/reviews/stats", {}),
    ("/reviews/export", ADMIN),
    ("/users/me", USER),
    ("/users/admins", USER),
    ("/admin/dashboard", ADMIN),
    ("/admin/config", ADMIN),
    ("/reviews/1", {}),
    ("/reviews/1/comments", {}),
    ("/users/alice/audit", ADMIN),
]

OUT = HERE / "results" / "work_equiv"


# --------------------------------------------------------------------------
# static: resolution-site census (mechanism, reported)
# --------------------------------------------------------------------------
def resolution_sites(pattern: str, model: str) -> dict:
    """Count DI resolution sites in a generated app's source.

    Purely syntactic and therefore crude, which is fine: its job is to make the
    runtime mechanism counters interpretable ("dependency-injector performs 2
    provider calls on this route"), not to classify anything.

    `yield_deps` counts yields ONLY inside functions that something actually
    passes to Depends(). Counting every yield in the file reported the lifespan
    and the s3 request_conn asynccontextmanager as "generator dependencies",
    which they are not -- neither is wired into the graph. A generator
    dependency is a generator that FastAPI is asked to resolve.
    """
    src = (HERE / "apps" / pattern / model / "app.py").read_text()
    tree = ast.parse(src)
    out = {"depends_defaults": 0, "provider_calls": 0,
           "injected_params": 0, "yield_deps": 0, "ctx_ctor_calls": 0}

    depends_targets: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) \
                and node.func.id in ("Depends", "Security") and node.args:
            a0 = node.args[0]
            if isinstance(a0, ast.Name):
                depends_targets.add(a0.id)
            elif isinstance(a0, ast.Attribute):
                depends_targets.add(a0.attr)

    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            f = node.func
            # providers.Singleton(UserService) etc. are wiring, not per-request
            if isinstance(f, ast.Attribute) and f.attr == "user_service":
                out["provider_calls"] += 1
            elif isinstance(f, ast.Name) and f.id == "_Ctx":
                out["ctx_ctor_calls"] += 1
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for d in node.args.defaults + [x for x in node.args.kw_defaults if x]:
                if isinstance(d, ast.Call) and isinstance(d.func, ast.Name) \
                        and d.func.id in ("Depends", "Security"):
                    out["depends_defaults"] += 1
            for a in list(node.args.args) + list(node.args.kwonlyargs):
                ann = a.annotation
                if ann is not None and "FromDishka" in ast.dump(ann):
                    out["injected_params"] += 1
            if node.name in depends_targets:
                for n in ast.walk(node):
                    if isinstance(n, (ast.Yield, ast.YieldFrom)):
                        out["yield_deps"] += 1
                        break
    return out


# --------------------------------------------------------------------------
# child: instrument core_read, then probe one arm
# --------------------------------------------------------------------------
def child(pattern: str, model: str) -> None:
    import importlib
    import json as _json
    from contextlib import asynccontextmanager as _acm, contextmanager as _cm

    import httpx

    import core_read

    # Every name below is resolved as a core_read module global by the generated
    # apps, so replacing the attribute here is enough -- PROVIDED the apps are
    # imported after this block, which is why sys.modules is cleared below.
    stats = {k: 0 for k in WORK_KEYS + MECH_KEYS}
    stats["hold_ms"] = 0.0
    armed = False

    orig = {n: getattr(core_read, n) for n in
            ["sync_conn", "async_conn", "_cursor", "_one", "_all",
             "require_role", "bearer_token"] + SERVICE_FNS + AUTH_ASYNC_FNS}

    # ---- pool: leases, returns, hold time ---------------------------------
    @_cm
    def sync_conn(path=None):
        if armed:
            stats["checkouts"] += 1
        t0 = time.perf_counter()
        with orig["sync_conn"](path) as c:
            try:
                yield c
            finally:
                if armed:
                    stats["returns"] += 1
                    stats["hold_ms"] += (time.perf_counter() - t0) * 1000.0

    @_acm
    async def async_conn(path=None):
        if armed:
            stats["checkouts"] += 1
        t0 = time.perf_counter()
        async with orig["async_conn"](path) as c:
            try:
                yield c
            finally:
                if armed:
                    stats["returns"] += 1
                    stats["hold_ms"] += (time.perf_counter() - t0) * 1000.0

    # ---- SQL counted in exactly one place ---------------------------------
    # Verified: both _one and _all funnel through the module-global _cursor, so
    # patching _cursor alone counts every statement exactly once and excludes the
    # PRAGMA statements issued once per pooled connection at pool construction
    # (we want request work, not pool setup). Rejected set_trace_callback: it is
    # not reliably proxied by aiosqlite.
    async def _cursor(conn, sql, params=()):
        if armed:
            stats["sql"] += 1
        return await orig["_cursor"](conn, sql, params)

    # ---- rows: REAL rows, not query count ---------------------------------
    # The previous version of this harness incremented a counter named `rows`
    # once per _all() call, so it measured list queries, not rows. It is fixed
    # here and _one is added so single-row reads contribute too.
    async def _one(conn, sql, params=()):
        r = await orig["_one"](conn, sql, params)
        if armed and r is not None:
            stats["rows"] += 1
        return r

    async def _all(conn, sql, params=()):
        r = await orig["_all"](conn, sql, params)
        if armed:
            stats["rows"] += len(r)
        return r

    core_read.sync_conn = sync_conn
    core_read.async_conn = async_conn
    core_read._cursor = _cursor
    core_read._one = _one
    core_read._all = _all

    # ---- auth + service call counts ---------------------------------------
    def _wrap_sync(name, key):
        f = orig[name]

        def g(*a, **kw):
            if armed:
                stats[key] += 1
            return f(*a, **kw)
        return g

    def _wrap_async(name, key):
        f = orig[name]

        async def g(*a, **kw):
            if armed:
                stats[key] += 1
            return await f(*a, **kw)
        return g

    core_read.require_role = _wrap_sync("require_role", "require_role")
    core_read.bearer_token = _wrap_sync("bearer_token", "bearer_token")
    for n in AUTH_ASYNC_FNS:
        setattr(core_read, n, _wrap_async(n, n))
    for n in SERVICE_FNS:
        setattr(core_read, n, _wrap_async(n, "service_calls"))

    # the generated apps do `from core_read import ...`, so they must be
    # imported AFTER the patches above.
    for name in list(sys.modules):
        if name.startswith("apps."):
            del sys.modules[name]

    sys.path.insert(0, str(HERE))

    @_acm
    async def load_app():
        mod = importlib.import_module(f"apps.{pattern}.{model}.app")
        app = mod.app
        # Count per-request context objects (s3 builds one; other arms have no
        # equivalent). A subclass wrapper, so no arm source is modified.
        if hasattr(mod, "_Ctx"):
            Base = mod._Ctx

            class CountingCtx(Base):
                def __init__(self, *a, **kw):
                    if armed:
                        stats["ctx_objects"] += 1
                    super().__init__(*a, **kw)

            mod._Ctx = CountingCtx
        async with app.router.lifespan_context(app):
            yield app

    async def run() -> dict:
        out = {}
        async with load_app() as app:
            transport = httpx.ASGITransport(app=app)
            async with httpx.AsyncClient(transport=transport, base_url="http://t") as c:
                for path, headers in PROBES:
                    for k in stats:
                        stats[k] = 0
                    stats["hold_ms"] = 0.0
                    # `armed` is a local of child(); run() must rebind THAT
                    # binding. A `global armed` here silently writes an unrelated
                    # module attribute and leaves every counter permanently
                    # disabled -- which is exactly what happened the first time
                    # this harness was run.
                    nonlocal armed
                    armed = True
                    r = await c.get(path, headers=headers)
                    armed = False
                    body = r.text
                    try:
                        body = _json.dumps(_json.loads(body), sort_keys=True)
                    except Exception:
                        pass
                    rec = {"status": r.status_code, "body": body}
                    rec.update({k: stats[k] for k in WORK_KEYS})
                    rec.update({k: stats[k] for k in MECH_KEYS})
                    out[path] = rec
        return out

    res = asyncio.run(run())

    # Self-test. A zero total is not a finding, it is a broken instrument: every
    # route in this study queries SQLite, so all-zero means the counters never
    # fired. Fail loudly rather than reporting a false clean bill of health.
    tot = {k: sum(v[k] for v in res.values()) for k in WORK_KEYS + MECH_KEYS}
    for k in ("checkouts", "returns", "sql", "rows", "service_calls"):
        if tot[k] == 0:
            raise SystemExit(f"SELF-TEST FAILED {pattern}.{model}: {k} never fired")
    # Every lease must be returned or we have leaked a pooled connection.
    if tot["checkouts"] != tot["returns"]:
        raise SystemExit(
            f"SELF-TEST FAILED {pattern}.{model}: "
            f"{tot['checkouts']} leases but {tot['returns']} returns -- leak")
    print("SELF-TEST ok {}.{}: {} sql={} rows={} svc={} auth={}/{} role={} "
          "hold={:.2f}ms ctx={}".format(
              pattern, model, tot["checkouts"], tot["sql"], tot["rows"],
              tot["service_calls"], tot["current_user"], tot["lookup_user"],
              tot["require_role"], tot["hold_ms"], tot["ctx_objects"]))

    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / f"{pattern}.{model}.json").write_text(
        _json.dumps(res, indent=1, sort_keys=True))
    print(f"OK {pattern}.{model}")


# --------------------------------------------------------------------------
# parent: drive children and print the matrix
# --------------------------------------------------------------------------
def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    for pattern, model in ARMS:
        r = subprocess.run([sys.executable, __file__, "--child", pattern, model],
                           capture_output=True, text=True, cwd=HERE)
        if r.returncode != 0:
            print(f"FAIL {pattern}.{model}\n{r.stdout}\n{r.stderr}")
            return 1
        print(r.stdout.strip())

    data = {f"{p}.{m}": json.loads((OUT / f"{p}.{m}.json").read_text())
            for p, m in ARMS}
    arm_keys = list(data)
    short = [k.replace("_", "")[:13] for k in arm_keys]

    def matrix(title, key, flag_mismatch=True):
        print("\n" + "=" * 100)
        print(title)
        print("=" * 100)
        print(f"{'route':<34}" + "".join(f"{s:>14}" for s in short))
        bad = []
        for path, _ in PROBES:
            vals = [data[k][path][key] for k in arm_keys]
            mismatch = flag_mismatch and len(set(vals)) != 1
            if mismatch:
                bad.append(path)
            tag = "   <-- MISMATCH" if mismatch else ""
            if key == "hold_ms":
                cells = "".join(f"{v:>14.2f}" for v in vals)
            else:
                cells = "".join(f"{v:>14}" for v in vals)
            print(f"{path:<34}" + cells + tag)
        return bad

    # ---- gated: work must be identical everywhere -------------------------
    failures = {}
    for k in ("checkouts", "returns", "sql", "rows", "require_role", "service_calls"):
        failures[k] = matrix(f"WORK: {k} per route   (gated -- must be identical)", k)
    failures["lookup_user"] = matrix(
        "WORK: lookup_user per route   (gated -- must be identical)", "lookup_user")

    # ---- reported: mechanism ---------------------------------------------
    matrix("MECHANISM: connection hold time ms per route   (reported, not gated)",
           "hold_ms", flag_mismatch=False)
    matrix("MECHANISM: current_user wrapper calls per route   (reported)", "current_user")
    matrix("MECHANISM: bearer_token header parses per route   (reported)", "bearer_token")
    matrix("MECHANISM: per-request context objects   (reported)", "ctx_objects")

    print("\n" + "=" * 100)
    print("STATIC: DI resolution sites per generated app   (the mechanism under test)")
    print("=" * 100)
    print(f"{'arm':<22}{'depends_defaults':>17}{'provider_calls':>16}"
          f"{'injected_params':>17}{'yield_deps':>12}{'ctx_ctor':>10}")
    for p, m in ARMS:
        s = resolution_sites(p, m)
        print(f"{p + '/' + m:<22}{s['depends_defaults']:>17}{s['provider_calls']:>16}"
              f"{s['injected_params']:>17}{s['yield_deps']:>12}{s['ctx_ctor_calls']:>10}")

    print("\n" + "=" * 100)
    print("RESPONSE IDENTITY  (bodies must be identical across arms)")
    print("=" * 100)
    bad = 0
    for path, _ in PROBES:
        bodies = {data[k][path]["body"] for k in arm_keys}
        statuses = {data[k][path]["status"] for k in arm_keys}
        if len(bodies) != 1 or len(statuses) != 1:
            bad += 1
            print(f"  DIVERGENCE {path}: statuses={statuses} bodies={len(bodies)}")
    print(f"  {len(PBOS := PROBES) - bad}/{len(PBOS)} routes identical across all "
          f"{len(arm_keys)} arms" + ("" if bad == 0 else f"  ({bad} DIVERGENT)"))

    # ---- verdict ----------------------------------------------------------
    print("\n" + "=" * 100)
    print("GATE")
    print("=" * 100)
    ok = True
    for k, routes in failures.items():
        if routes:
            ok = False
            print(f"  FAIL  {k} differs on: {', '.join(routes)}")
        else:
            print(f"  PASS  {k} identical across all {len(arm_keys)} arms on all "
                  f"{len(PROBES)} routes")
    if bad:
        ok = False
        print(f"  FAIL  response identity: {bad} divergent route(s)")
    else:
        print(f"  PASS  response identity")

    # Work totals, as a single readable summary.
    print("\n  totals over the 12-route sweep:")
    print(f"  {'arm':<22}" + "".join(f"{k:>13}" for k in
                                     ("checkouts", "sql", "rows", "svc", "hold_ms")))
    for p, m in ARMS:
        k = f"{p}.{m}"
        t = {x: sum(v[x] for v in data[k].values())
             for x in WORK_KEYS + MECH_KEYS}
        print(f"  {k:<22}" + f"{t['checkouts']:>13}{t['sql']:>13}{t['rows']:>13}"
              f"{t['service_calls']:>13}{t['hold_ms']:>13.2f}")

    print("\nJSON written to", OUT)
    if not ok:
        print("\nGATE FAILED -- do NOT run the study until this is green.")
        return 1
    print("\nGATE PASSED -- arms do identical work; safe to run the study.")
    return 0


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--child":
        child(sys.argv[2], sys.argv[3])
        sys.exit(0)
    sys.exit(main())