import json, subprocess, sys, time, urllib.request
sys.path.insert(0,"/root/study" if False else ".")
import runner
port=8900
def hit(path, hdrs=None, n=60):
    t=[]
    for _ in range(n):
        req=urllib.request.Request(f"http://127.0.0.1:{port}{path}", headers=hdrs or {})
        s=time.perf_counter()
        with urllib.request.urlopen(req, timeout=10) as r: r.read()
        t.append((time.perf_counter()-s)*1000)
    t.sort(); return t[len(t)//2], t[int(len(t)*0.95)]
AUTH={"Authorization":"Bearer user-token"}
for arm in ("p1_direct","p4_container"):
    for model in ("sync",):
        log=runner.HERE/"results"/"cells"/f"seq-{arm}.log"
        p=runner.start_server(f"apps.{arm}.{model}.app:app", port, log)
        try:
            time.sleep(1.0)
            for label,path,h in (("public /health","/health",None),
                                 ("auth   /users/me","/users/me",AUTH),
                                 ("auth   /admin/dashboard","/admin/dashboard",AUTH)):
                try:
                    m,p95=hit(path,h)
                    print(f"  {arm:<13} {label:<24} p50={m:7.2f}ms p95={p95:7.2f}ms", flush=True)
                except Exception as e:
                    print(f"  {arm:<13} {label:<24} ERR {type(e).__name__}", flush=True)
        finally:
            p.kill(); time.sleep(1)
