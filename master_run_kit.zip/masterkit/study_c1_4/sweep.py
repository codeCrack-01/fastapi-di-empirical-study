"""sweep.py -- LOCAL directional sweep. NOT the study harness, NOT publishable.

One cell per (arm, rate), one rep, no drift cells. The point is a
rate-response curve per arm so the eight arms can be ranked against each
other cheaply, before spending box time. Run only after smoke.py reports
byte-identical output on this machine.
"""
import json
import os
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import runner

RATES = [int(x) for x in os.environ.get("RATES", "400,600,800").split(",")]
ARMS = [(p, m) for p in ("p1_direct", "p2_depends", "p3_middleware", "p4_container")
        for m in ("sync", "async")]
OUT = runner.HERE / "results" / "local"
CELLS = runner.HERE / "results" / "cells"
rows = []

for pattern, model in ARMS:
    module = f"apps.{pattern}.{model}.app:app"
    for rate in RATES:
        tag = f"local-{pattern}-{model}-{rate}"
        log = CELLS / f"{tag}.server.log"
        summary = CELLS / f"{tag}.summary.json"
        for f in (log, summary):
            f.unlink(missing_ok=True)
        proc = runner.start_server(module, 8900, log)
        try:
            env = runner._env()
            env.update({
                "TARGET_URL": "http://127.0.0.1:8900", "SCENARIO": "steady",
                "RATE": str(rate), "WINDOW_MS": "30000", "WARMUP_MS": "10000",
                "COOLDOWN_MS": "12000", "RAMP_MAX": str(rate), "RAMP_MS": "8000",
                "SUMMARY_FILE": str(summary),
            })
            cmd = ["taskset", "-c", runner.K6_CORES, "k6", "run", "--quiet",
                   "k6/harness.js"]
            t0 = time.time()
            subprocess.run(cmd, cwd=str(runner.HERE), env=env,
                           capture_output=True, text=True)
            dur = round(time.time() - t0, 1)
            d = json.loads(summary.read_text()) if summary.exists() else {}
            win = d.get("window") or {}
            warm = d.get("warmup") or {}
            reqs = d.get("window_requests") or 0
            row = {
                "arm": f"{pattern}/{model}", "rate": rate, "seconds": dur,
                "window_requests": reqs,
                "window_errors": d.get("window_errors") or 0,
                "checkFailures": d.get("checkFailures") or 0,
                "p50_ms": win.get("p50"), "p95_ms": win.get("p95"),
                "mean_ms": win.get("mean"), "max_ms": win.get("max"),
                "warm_p95_ms": warm.get("p95"),
                "cpu_seconds": d.get("cpu_seconds"),
                "returncode": d.get("returncode"),
            }
            row["throughput_rps"] = round(reqs / 30.0, 1) if reqs else 0.0
            row["achieved"] = round(row["throughput_rps"] / rate, 3) if rate else None
            rows.append(row)
            print(f"{row['arm']:<22} @{rate:<5} reqs={reqs:<7} rps={row['throughput_rps']:<8} "
                  f"p50={row['p50_ms']} p95={row['p95_ms']} ach={row['achieved']} "
                  f"fails={row['checkFailures']} dur={dur}s", flush=True)
        finally:
            try:
                proc.kill()
            except Exception:
                pass

OUT.mkdir(parents=True, exist_ok=True)
(OUT / "sweep.json").write_text(json.dumps(rows, indent=2))
print("written", OUT / "sweep.json", flush=True)
print("DONE", flush=True)
