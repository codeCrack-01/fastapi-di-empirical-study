import json, os, re, signal, subprocess, sys, threading, time, collections, urllib.request
sys.path.insert(0,".")
import runner
port=8900; RATE=int(os.environ.get("R","400")); THRESH=float(os.environ.get("THRESH","8"))
log=runner.HERE/"results"/"cells"/"p4hunt.server.log"
summary=runner.HERE/"results"/"cells"/"p4hunt.summary.json"
env=runner._env(); env["PYTHONFAULTHANDLER"]="1"
os.environ["PYTHONFAULTHANDLER"]="1"
proc=runner.start_server("apps.p4_container.sync.app:app", port, log)
time.sleep(1.5)
kenv=runner._env(); kenv.update({"TARGET_URL":f"http://127.0.0.1:{port}","SCENARIO":"steady",
  "RATE":str(RATE),"WINDOW_MS":"30000","WARMUP_MS":"10000","COOLDOWN_MS":"12000",
  "RAMP_MAX":str(RATE),"RAMP_MS":"8000","SUMMARY_FILE":str(summary)})
k=threading.Thread(target=lambda: subprocess.run(
  ["taskset","-c",runner.K6_CORES,"k6","run","--quiet","k6/harness.js"],
  cwd=str(runner.HERE),env=kenv,capture_output=True,text=True),daemon=True)
k.start()
stalled=False; t0=time.time()
while time.time()-t0 < 300:
    time.sleep(1.0)
    try:
        s=time.perf_counter()
        urllib.request.urlopen(f"http://127.0.0.1:{port}/health",timeout=THRESH).read()
        lat=(time.perf_counter()-s)*1000
    except Exception as e:
        print(f"  [{(time.time()-t0):6.1f}s] health probe FAILED ({type(e).__name__}) -> dumping threads", flush=True)
        stalled=True
        os.kill(proc.pid, signal.SIGABRT); break
    else:
        if lat > 2000:
            print(f"  [{(time.time()-t0):6.1f}s] health p={lat:.0f}ms (slow)", flush=True)
if not stalled:
    print("  no stall within 300s", flush=True); proc.kill()
else:
    time.sleep(4)
    txt=log.read_text(errors="replace") if log.exists() else ""
    frames=re.findall(r'File "([^"]+)", line \d+ in (\S+)', txt)
    top=collections.Counter(f"{f[0].split('/')[-1]}:{f[1]}" for f in frames)
    print(f"  --- dump {len(txt)} bytes; top frames ---", flush=True)
    for kk,vv in top.most_common(15): print(f"    {vv:>3}x {kk}", flush=True)
    print("  --- lines naming the suspects ---", flush=True)
    for line in txt.splitlines():
        if any(w in line for w in ("lock","Semaphore","acquire","get_db","conn_ctx","sync_conn","Singleton","provider","user_service","queue","Condition")):
            print("   ", line.strip()[:150], flush=True)
proc.kill()
