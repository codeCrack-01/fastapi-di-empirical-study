"""test_gen_apps.py — proof that a failed rebuild cannot destroy the study apps.

The app.py files under apps/ ARE the substrate of the long run. The generator
that produces them used to delete the whole directory and only then discover it
had no builder for the fourth pattern -- so a one-line mismatch between two
constants could leave the study with nothing to measure.

That is not a hypothetical: PATTERNS listed s4_dependency_injector and
s4_dishka while BUILDERS only had s4_container, so main() raised KeyError after
shutil.rmtree had already run. Amendment 14 later built s4_dishka, which retired
that mismatch -- and silently retired this test's own case 2 with it, because
the test injected s4_dishka as its orphan-builder probe. The probe now uses a
name in neither list, and the app count is derived instead of hard-coded.

These tests pin the three properties that replace it:

  1. an incomplete PATTERNS/BUILDERS pairing is refused BEFORE anything is written
  2. a builder that emits broken Python leaves the live apps untouched
  3. a good build replaces them atomically, with no staging or backup left behind

Run:  python test_gen_apps.py
"""

from __future__ import annotations

import hashlib
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import gen_apps  # noqa: E402


def snapshot() -> dict:
    out = {}
    for p in sorted(HERE.glob("apps/*/*/app.py")):
        out[str(p.relative_to(HERE))] = hashlib.sha256(p.read_bytes()).hexdigest()
    return out


def leftovers() -> list:
    return [p.name for p in (HERE / "apps.staging", HERE / "apps.backup") if p.exists()]


def check(cond: bool, label: str, detail: str = "") -> bool:
    print(f"  [{'PASS' if cond else 'FAIL'}] {label}" + (f"  {detail}" if detail else ""))
    return cond


def main() -> int:
    ok = True
    before = snapshot()
    print(f"live apps: {len(before)} files\n")

    if not before:
        print("no apps present; run gen_apps.py first")
        return 1

    # --- 1. missing builder is refused before anything is destroyed ---------
    print("case 1: PATTERNS names a pattern with no builder")
    saved = dict(gen_apps.BUILDERS)
    gen_apps.BUILDERS.pop("s4_container")
    raised = False
    try:
        gen_apps.validate()
    except SystemExit as exc:
        raised = "nothing was deleted" in str(exc)
    ok &= check(raised, "validate() refuses with a clear, non-destructive error")
    gen_apps.BUILDERS.clear()
    gen_apps.BUILDERS.update(saved)
    ok &= check(snapshot() == before, "live apps untouched")
    ok &= check(not leftovers(), "no staging/backup residue", str(leftovers()))

    # --- 2. orphan builder is also refused --------------------------------
    # A name that is in NEITHER PATTERNS nor BUILDERS. This used to be
    # s4_dishka, which is a real arm as of Amendment 14, so injecting it no
    # longer created an orphan: validate() found no problem, the test silently
    # stopped testing anything, and the pop() then deleted the real builder --
    # which is why cases 3 and 4 started failing too.
    orphan = "s4_not_a_pattern"
    print("\ncase 2: BUILDERS holds a pattern PATTERNS will never generate")
    gen_apps.BUILDERS[orphan] = lambda p, m: ""
    raised = False
    try:
        gen_apps.validate()
    except SystemExit as exc:
        raised = "never be generated" in str(exc)
    ok &= check(raised, "orphan builder refused")
    gen_apps.BUILDERS.pop(orphan)
    ok &= check(snapshot() == before, "live apps untouched")
    ok &= check(set(gen_apps.BUILDERS) == set(gen_apps.PATTERNS),
                "BUILDERS restored", str(sorted(gen_apps.BUILDERS)))

    # --- 3. a builder emitting broken Python must not swap ------------------
    print("\ncase 3: a builder emits syntactically invalid Python")
    gen_apps.BUILDERS["s2_depends"] = lambda p, m: "def broken(:\n    pass\n"
    failed = False
    try:
        gen_apps.main()
    except SystemExit as exc:
        failed = exc.code == 1
    ok &= check(failed, "build refuses to install a broken app")
    gen_apps.BUILDERS["s2_depends"] = saved["s2_depends"]
    after_bad = snapshot()
    ok &= check(after_bad == before,
                "live apps survive a failed build completely intact")
    ok &= check(not leftovers(), "staging cleaned up after failure",
                str(leftovers()))

    # --- 4. a good build swaps atomically ----------------------------------
    print("\ncase 4: clean rebuild")
    gen_apps.main()
    ok &= check(snapshot() == before, "regenerated apps are byte-identical")
    ok &= check(not leftovers(), "no staging/backup residue", str(leftovers()))
    expected = len(gen_apps.PATTERNS) * len(gen_apps.MODELS)
    ok &= check(len(before) == expected,
                f"{expected} apps present ({len(gen_apps.PATTERNS)} patterns x "
                f"{len(gen_apps.MODELS)} models)", str(len(before)))

    print("\n" + ("ALL CHECKS PASSED" if ok else "SOME CHECKS FAILED"))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())