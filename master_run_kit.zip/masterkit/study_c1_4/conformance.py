"""conformance.py — report each harness arm's intent against the corpus classifier.

The harness's four arms are hand-built exemplars. Each one is *written* to
instantiate a dependency-injection pattern: s1_direct resolves nothing, s2_depends
lets FastAPI resolve a graph, s3_middleware carries a context object on
request.state from middleware, s4_container reaches a dependency-injector
DeclarativeContainer. That is a claim about how the apps were built, and it is
true by construction.

This script does NOT re-derive that claim from the apps, because the tool that
would do so cannot answer it. `extractor.verdict.classify` assigns one of S1-S4
to a *repository* by asking which resolution mechanism the code uses. That is a
coarser question than "which pattern was this app built with", and on two arms the
two questions come apart:

  s1_direct      -> S2. It has zero DI constructs, and the classifier routes
                    "FastAPI app present, no hand-rolled or container
                    resolution" to S2. That bucket is a superset -- 737 of the
                    1971 corpus S2 rows also have zero constructs.

  s3_middleware  -> S2. The ambient_state_provider rule requires the ambient read
                    to sit inside a RETURN expression. This arm reads by
                    assignment (`ctx = request.state.ctx`). The receiver
                    request.state IS in the supported receiver list; only the
                    access shape is invisible to the rule.

Both divergences are understood, and both are consequences of the classifier
being coarser than the question -- not defects in the arms. They are reported
here rather than left for a reader to discover, because an unstated mismatch
between "our arm is S3" and "the classifier says S2" would otherwise look like a
validity failure in the study.

What this script deliberately does NOT do is "fix" the classifier. Extending
the ambient-read rule to assignment-shaped access would move the published corpus
distribution, force a full re-run over 2,179 repositories, and invalidate the
S3 precision audit -- all to tidy a labelling claim about eight synthetic apps.

Exit code is 0 when every arm either matches its intent or is a recorded known
divergence. A NEW, unrecorded divergence is a failure: it would mean the apps
stopped matching what the study says they are.

Run:  python conformance.py
"""

from __future__ import annotations

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
sys.path.insert(0, str(HERE))
# extractor/ is a flat module directory, not a package (no __init__.py), so its
# modules are imported by bare name rather than as extractor.<module>.
sys.path.insert(0, str(REPO / "extractor"))

from extract import analyze_repo  # noqa: E402
from verdict import classify_report  # noqa: E402

import gen_apps  # noqa: E402


def check_arm(pattern: str) -> dict:
    """Classify one arm (both models merged) and compare with its intent."""
    intent, how = gen_apps.ARM_INTENT[pattern]
    verdicts = {}
    for model in gen_apps.MODELS:
        arm_dir = gen_apps.APPS / pattern / model
        report = analyze_repo(arm_dir)
        verdicts[model] = classify_report(report)

    # A pattern is meant to hold across both execution models. If the two
    # models disagree, the arm is not internally consistent and that is a real
    # finding, not a classifier artefact.
    labels = {m: v.label for m, v in verdicts.items()}
    consistent = len(set(labels.values())) == 1
    observed = labels[gen_apps.MODELS[0]] if consistent else "/".join(
        sorted(set(labels.values())))

    expected_div, div_reason = gen_apps.KNOWN_DIVERGENCE.get(pattern, (None, None))
    if consistent and observed == intent:
        status, detail = "MATCH", ""
    elif expected_div and observed == expected_div:
        status, detail = "KNOWN_DIVERGENCE", div_reason
    else:
        status, detail = "UNRECORDED_DIVERGENCE", (
            f"classifier says {observed!r} but intent is {intent!r} and no "
            f"divergence is recorded for this arm"
        )

    return {
        "pattern": pattern, "intent": intent, "how": how,
        "observed": observed, "status": status, "detail": detail,
        "consistent_across_models": consistent,
        "per_model": labels,
        "reasons": {m: v.reason for m, v in verdicts.items()},
        "constructs": {
            m: {
                "C1_depends": getattr(report.aggregate, "depends_total", None),
                "C2_security": getattr(report.aggregate, "security_total", None),
                "C3_annotated": getattr(report.aggregate,
                                        "annotated_depends_total", None),
                "C4_yield_dep": getattr(report.aggregate, "yield_dep_total", None),
            }
            for m, report in (
                (mo, analyze_repo(gen_apps.APPS / pattern / mo))
                for mo in gen_apps.MODELS
            )
        },
    }


def main() -> int:
    print("Harness arm conformance: build intent vs corpus classifier\n")
    print("The arms instantiate their patterns BY CONSTRUCTION. The classifier")
    print("labels repositories by which resolution mechanism the code uses, which")
    print("is a coarser question. Divergences below are understood and recorded.\n")

    rows = [check_arm(p) for p in gen_apps.PATTERNS]

    hdr = f"{'arm':<16} {'intent':<7} {'classifier':<11} {'status':<22} model-consistent"
    print(hdr)
    print("-" * len(hdr))
    for r in rows:
        print(f"{r['pattern']:<16} {r['intent']:<7} {r['observed']:<11} "
              f"{r['status']:<22} {r['consistent_across_models']}")

    print("\nconstructs per arm (C1 Depends / C2 Security / C3 Annotated / C4 yield):")
    for r in rows:
        c = r["constructs"]
        print(f"  {r['pattern']:<16} sync  C1={c['sync']['C1_depends']:<4} "
              f"C2={c['sync']['C2_security']:<4} C3={c['sync']['C3_annotated']:<4} "
              f"C4={c['sync']['C4_yield_dep']:<4}   |  async "
              f"C1={c['async']['C1_depends']:<4} C2={c['async']['C2_security']:<4} "
              f"C3={c['async']['C3_annotated']:<4} C4={c['async']['C4_yield_dep']}")

    print("\nmechanism establishing each arm:")
    for r in rows:
        print(f"  {r['pattern']:<16} {r['how']}")

    divs = [r for r in rows if r["status"] != "MATCH"]
    if divs:
        print(f"\nrecorded divergences ({len(divs)}):")
        for r in divs:
            print(f"\n  {r['pattern']}  intent {r['intent']} -> classifier {r['observed']}")
            for line in _wrap(r["detail"], 74):
                print(f"    {line}")
            print(f"    classifier reason: {r['reasons'][gen_apps.MODELS[0]]}")

    bad = [r for r in rows if r["status"] == "UNRECORDED_DIVERGENCE"]
    inconsistent = [r for r in rows if not r["consistent_across_models"]]
    if bad:
        print(f"\nFAIL: {len(bad)} arm(s) diverge from intent with no recorded "
              f"explanation:")
        for r in bad:
            print(f"  {r['pattern']}: {r['detail']}")
        return 1
    if inconsistent:
        print(f"\nFAIL: {len(inconsistent)} arm(s) classify differently between "
              f"sync and async, so the arm is not internally consistent:")
        for r in inconsistent:
            print(f"  {r['pattern']}: {r['per_model']}")
        return 1

    print(f"\nOK: {len(rows) - len(divs)}/{len(rows)} arms match intent outright, "
          f"{len(divs)} carry a recorded divergence, 0 unrecorded.")
    return 0


def _wrap(text: str, width: int) -> list[str]:
    words, line, out = text.split(), "", []
    for w in words:
        if len(line) + len(w) + 1 > width:
            out.append(line)
            line = w
        else:
            line = f"{line} {w}".strip()
    if line:
        out.append(line)
    return out


if __name__ == "__main__":
    raise SystemExit(main())