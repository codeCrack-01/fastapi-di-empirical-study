"""config_hash.py — sha256 over the exact files that define the study config.

A pre-registration is only useful if the thing it describes is pinned. This
hash covers the files that determine what is measured:

  generator   how the 8 apps are built, from one route table
  service     the SQL and response payloads
  routes      the 12 read routes
  pool        connection acquisition, held constant across both models
  runner      worker count, core pinning, warmup/window/cooldown, the cell loop
  pinning     which siblings are offlined, and the disjointness check
  orchestrator the shared ladder, the rep allocation, the ordering, per-cell
              fault isolation, resume, and the host-drift reference cells
  harness     the k6 workload mix, lat_cell percentiles and window bucketing
  database    the read-only seed builder and its verification
  smoke       the functional-equivalence gate
  analysis    the statistics

Any edit to any of these invalidates the pre-registration and requires a new
hash and an explicit amendment. Run before the study, commit the value.

Note that run_matrix.py was added to this list in amendment 2: it selects each
arm's rate and defines the grid, so a pre-registration that omitted it was not
actually pinning what gets measured. Amendment 7 further removed the two
knee-derived entries; see RETIRED_FROM_CONFIG.

Note that test_resume.py, test_gen_apps.py and conformance.py are deliberately
NOT in this list. They are verification tools: they validate that the harness
resumes exactly, that the generator cannot destroy the substrate, and that each
arm reports the pattern it was built to instantiate. None of them contributes to
what any measurement IS, so pinning them would conflate "this is what we measured"
with "this is how we checked the measurement" -- and would force a new hash and
a new amendment every time a test is improved.

The declarations those three files exist to verify -- ARM_INTENT,
KNOWN_DIVERGENCE, PLANNED_NOT_BUILT -- all live in gen_apps.py, which IS pinned.
So what actually matters (which pattern each arm is meant to instantiate, and
which classifier divergences are acknowledged) is covered, without making test
edits churn the pre-registration.

Run:  python config_hash.py
"""

from __future__ import annotations

import hashlib
import importlib.metadata
import json
import platform
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent

# (label, path relative to this file) -- the pre-registration quotes this list
CONFIG_FILES = [
    ("service", "core_read.py"),
    ("routes", "routes_read.py"),
    ("generator", "gen_apps.py"),
    ("pool+runner", "runner.py"),
    ("pinning", "prepare_box.py"),
    ("orchestrator", "run_matrix.py"),
    ("harness", "k6/harness.js"),
    ("database", "build_db.py"),
    ("seed", "_seed_source.py"),
    ("smoke", "smoke.py"),
    ("analysis", "analyze.py"),
    ("drift", "drift_report.py"),
    # Amendment 10 ADDS this. It installs the measurement environment itself
    # (k6 version, Python toolchain), so it decides what the numbers mean in the
    # same way runner.py and the harness do. Its absence was a real gap: nothing
    # in the repo installed k6 or uv, so a freshly provisioned box could not run
    # a cell at all. See bootstrap_box.sh.
    ("bootstrap", "bootstrap_box.sh"),
    # Pinned because it is the gate that decides whether an arm is measurable at
    # all. smoke.py and work_equiv.py both drive arms SEQUENTIALLY and passed an
    # arm that failed 100% of requests at 600 rps: s3_middleware/sync deadlocked
    # on unbounded admission against the 8-slot sync pool and the 8-token thread
    # limiter, and the run was launched on that evidence. Hashing the gate records
    # that the pre-flight which admitted this run included a concurrency check,
    # so a later reader can tell the difference between a run that was checked for
    # wedges and one that was not.
    ("concurrency", "concurrency_gate.py"),
]

# Amendment 7 REMOVED "knee" (knee.py) and "smoke-knees" (smoke_knees.py) from
# this list. Both files still exist and are kept for provenance, but the shared
# offered-load ladder derives saturation by interpolating each arm's own curve
# afterwards, so neither file contributes anything to what gets measured. Leaving
# them pinned would have asserted a dependency that no longer exists, and leaving
# them unmentioned would have hidden a real deletion -- so the removal is stated
# here and in the amendment rather than left to be inferred.
RETIRED_FROM_CONFIG = [
    ("knee", "knee.py"),
    ("smoke-knees", "smoke_knees.py"),
]


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def combined_hash() -> tuple[str, dict]:
    per_file = {}
    combined = hashlib.sha256()
    for label, rel in CONFIG_FILES:
        p = HERE / rel
        if not p.exists():
            raise SystemExit(f"FATAL: config file missing: {rel}")
        d = file_sha256(p)
        per_file[label] = {"file": rel, "sha256": d}
        # order matters and is fixed by CONFIG_FILES
        combined.update(f"{label}:{rel}:{d}\n".encode())
    return combined.hexdigest(), per_file


def versions() -> dict:
    """Exact runtime versions of everything the study's behaviour depends on.

    Uses importlib.metadata rather than __import__(m).__version__: anyio has no
    __version__ attribute, so the naive lookup reported "unknown" -- but the
    AnyIO threadpool size is a stated design parameter, so its version has to be
    recorded.
    """
    out = {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
    }
    for dist, mod in (
        ("fastapi", "fastapi"), ("starlette", "starlette"), ("anyio", "anyio"),
        ("pydantic", "pydantic"), ("uvicorn", "uvicorn"),
        ("aiosqlite", "aiosqlite"), ("dependency-injector", "dependency_injector"),
        # Amendment 14 ADDS dishka. One of the five arms is built by this library,
        # so its version decides what that arm IS, in the same way
        # dependency-injector's version decides what s4_container is. Omitting it
        # would leave the amended study pinning four libraries out of five.
        ("dishka", "dishka"),
    ):
        try:
            out[dist] = importlib.metadata.version(dist)
        except importlib.metadata.PackageNotFoundError:
            out[dist] = "not installed"
    try:
        import anyio
        # anyio.get_backend() only resolves inside a running event loop, so
        # sniff it there and fall back to uvicorn's default, which is asyncio.
        out["anyio_backend"] = anyio.get_backend()
    except Exception:  # noqa: BLE001
        out["anyio_backend"] = "asyncio (uvicorn default)"
    try:
        import subprocess
        out["k6"] = subprocess.run(["k6", "version"], capture_output=True,
                                   text=True).stdout.split()[1]
    except Exception:  # noqa: BLE001
        out["k6"] = "unknown"
    return out


def main() -> int:
    combined, per_file = combined_hash()
    payload = {
        "config_sha256": combined,
        "files": per_file,
        "versions": versions(),
        "database_sha256": file_sha256(HERE / "results" / "reviewgate_ro.db")
        if (HERE / "results" / "reviewgate_ro.db").exists() else None,
    }
    out = HERE / "results" / "config_hash.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2))

    print(f"config_sha256  {combined}")
    print()
    for label, info in per_file.items():
        print(f"  {label:12s} {info['sha256'][:16]}  {info['file']}")
    print()
    for k, v in payload["versions"].items():
        print(f"  {k:20s} {v}")
    print()
    print(f"  database sha256  {(payload['database_sha256'] or 'n/a')[:16]}")
    print(f"written {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
