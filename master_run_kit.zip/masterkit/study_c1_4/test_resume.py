"""test_resume.py -- proof that an interrupted run resumes exactly.

The 13-hour run is the largest single commitment in this project, so the claim
"kill it and nothing measured is lost" has to be demonstrated rather than
asserted. This test hard-kills a run mid-flight with SIGKILL -- no cleanup, no
flush-on-exit, exactly like a box losing the session -- restarts it, and then
checks the recorded data for the two properties that matter:

  * **no duplicates** -- no (condition, rep) pair has more than one successful row
  * **no gaps**      -- every cell in the plan has exactly one successful row

It also covers fault isolation: a cell that raises must be recorded as failed
and the session must continue, and on restart a transient failure is retried
while a permanently broken cell is abandoned after MAX_ATTEMPTS rather than
retried forever.

Real cells are not run. `run_ramp` is replaced with a stub, so no server starts,
no load is generated and no CPU pinning is touched; the unit under test is the
bookkeeping in run_matrix, which is where the risk actually is.

    python test_resume.py            # all three phases
"""

from __future__ import annotations

import csv
import os
import signal
import subprocess
import sys
import tempfile
import time
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

STUB_SLEEP_S = float(os.environ.get("STUB_SLEEP_S", "0.04"))
MARKER = "CELL_DONE "


# --------------------------------------------------------------------------
# child process: run run_matrix with the cell executor stubbed out
# --------------------------------------------------------------------------
def child_run(here: str, fail_mode: str) -> int:
    """Run the real main() with run_ramp replaced by a stub.

    Prints one MARKER line per *recorded* row so the parent knows when to kill.
    """
    import run_matrix
    import runner

    # The layout check and the database hash are box concerns, not logic under
    # test. Neutralised so the test needs no SMT changes and no database.
    run_matrix.assert_disjoint = lambda: None
    run_matrix.sha256_db = lambda: "stubdbhash"
    run_matrix.HERE = Path(here)

    state = Counter()

    def fake_run_ramp(module, port, rate, window_s, warmup_s, cooldown_s,
                      tag="cell", **kw):
        state["n"] += 1
        seq = state["n"]
        # Announce from *inside* the executor so the parent can kill mid-flight.
        print(f"{MARKER}{seq}", flush=True)
        time.sleep(STUB_SLEEP_S)

        if fail_mode == "periodic" and seq % 5 == 0:
            raise RuntimeError(f"injected transient fault on stub cell {seq}")
        if fail_mode == "always-on-700" and rate == 700:
            raise RuntimeError("injected permanent fault at rate 700")

        # NB: inside a class body `rate = rate` would read the class-local name
        # (class bodies use LOAD_NAME, which does not see the enclosing scope) and
        # raise NameError. Alias it.
        my_rate = rate

        class R:
            rate = my_rate
            window = {"p50": 1.0, "p95": 2.0, "mean": 1.2, "max": 4.0}
            cell = {"p50": 1.0, "p95": 2.0, "p99": 3.0, "max": 4.0, "count": 100}
            # Amendment 11: k6's sub-ms timer is the primary latency source.
            http = {"p50": 1.02, "p95": 2.31, "p99": 3.14, "max": 4.2,
                    "count": 100}
            load_fidelity = 0.99
            dropped_iterations = 0
            timed_out = False
            achieved = 0.99
            checks = {"passes": 100, "fails": 0}
            returncode = 0
            startup_ms = 300.0
            cpu_seconds = 1.5
            rss_peak_mb = 100.0
            db_sha256_before = "stubdbhash"
            db_sha256_after = "stubdbhash"
            extra = {"window_requests": 100, "window_errors": 0,
                     "window_error_rate": 0.0, "cpu_seconds_per_req": 0.015}

            # matches the real property on runner.RampResult
            @property
            def db_unchanged(self) -> bool:
                return True

        return R()

    run_matrix.run_ramp = fake_run_ramp
    run_matrix.ARM = lambda pattern, model: f"{pattern}.{model}"

    argv = ["run_matrix.py", "--main", "--no-drift"]
    old = sys.argv
    sys.argv = argv
    try:
        rc = run_matrix.main()
    finally:
        sys.argv = old
    return rc


# --------------------------------------------------------------------------
# parent: drive the phases and verify
# --------------------------------------------------------------------------
def launch(here: str, fail_mode: str, kill_after: int | None = None) -> tuple[int, int]:
    """Start a child; SIGKILL it after `kill_after` recorded rows if asked."""
    env = dict(os.environ, STUB_SLEEP_S=str(STUB_SLEEP_S))
    proc = subprocess.Popen(
        [sys.executable, str(Path(__file__).resolve()), "--child", here, fail_mode],
        env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
        bufsize=1,
    )
    recorded = 0
    assert proc.stdout is not None
    for line in proc.stdout:
        if line.startswith(MARKER):
            recorded += 1
            if kill_after and recorded >= kill_after:
                proc.send_signal(signal.SIGKILL)
                break
    proc.wait(timeout=120)
    return proc.returncode, recorded


def read_rows(csv_path: Path) -> list[dict]:
    if not csv_path.exists():
        return []
    with open(csv_path) as fh:
        return list(csv.DictReader(fh))


def summarise(rows: list[dict]) -> dict:
    succ = Counter((r["condition"], r["rep"]) for r in rows if r["failed"] == "0")
    dupes = {k: v for k, v in succ.items() if v > 1}
    attempts = Counter((r["condition"], r["rep"]) for r in rows)
    return {
        "rows": len(rows),
        "success_rows": sum(succ.values()),
        "unique_ok": len(succ),
        "duplicate_success_keys": dupes,
        "failed_rows": sum(1 for r in rows if r["failed"] != "0"),
        "exhausted": sum(1 for k, n in attempts.items()
                         if succ.get(k, 0) == 0 and n >= 3),
    }


def check(cond: bool, label: str, detail: str = "") -> bool:
    print(f"  [{'PASS' if cond else 'FAIL'}] {label}" + (f"  {detail}" if detail else ""))
    return cond


def main() -> int:
    import run_matrix
    ok = True

    # ---- phase 0: the broken-plumbing guard, as a pure predicate ----------
    # Amendment 10. A successful cell that served the offered load but returned
    # no latency sample means the primary metric is not reaching us. That is
    # silent otherwise: cell_p99=None is written, the cell counts as successful,
    # and 568 cells finish "cleanly" before analysis reports "no data".
    #
    # The cases that must NOT trip it matter as much as the one that must: a
    # saturated cell legitimately has no p99 and is recorded as saturation
    # evidence, not halted on.
    # Amendment 11 renamed the plumbing being guarded: http_p99 (k6's sub-ms
    # timer) is now the primary, with cell_p99 kept as a coarse cross-check. The
    # predicate fires if EITHER is missing, so every case below sets both.
    print("phase 0: no_latency_contradiction guard (Amendments 10 + 11)")
    floor = run_matrix.LOAD_FIDELITY_FLOOR

    def row(http_p99, cell_p99, fid, failed=0):
        return {"failed": failed, "http_p99": http_p99,
                "cell_p99": cell_p99, "load_fidelity": fid}

    cases = [
        (row(None, None, 1.0), True,
         "served fully, no latency -> plumbing broken"),
        (row(None, 3.0, 1.0), True,
         "primary http_p99 missing -> broken even though cell_p99 landed"),
        (row(3.1, None, 1.0), True,
         "cell_p99 missing -> the lat_cell trend specifically is broken"),
        (row(None, None, 0.99), True,
         "just above floor -> still a contradiction"),
        (row(None, None, 0.999), True,
         "long saturated arm at fidelity 0.999 -> still a contradiction"),
        (row(None, None, 0.94), False,
         "below floor: saturation evidence, do not halt"),
        (row(None, None, 0.0), False,
         "served nothing: saturation, do not halt"),
        (row(None, None, None), False,
         "fidelity unknown: no evidence load was served"),
        (row(41.2, 41.0, 1.0), False,
         "normal successful cell"),
        (row(None, None, 1.0, failed=1), False,
         "already a failed cell: retry path owns it"),
        (row(0.0, 0.0, 1.0), False,
         "p99 of 0.0 is a value, not a null"),
        (row(0.0, None, 1.0), True,
         "http_p99 of 0.0 is a value; the missing cell_p99 is still a break"),
    ]
    for row, want, label in cases:
        got = run_matrix.no_latency_contradiction(row)
        ok &= check(got == want, f"guard: {label}",
                    f"got {got}, want {want}")
    print(f"  (load-fidelity floor = {floor})")

    with tempfile.TemporaryDirectory(prefix="resume-test-") as td:
        csv_path = Path(td) / "results" / "main" / "cells.csv"
        plan = run_matrix.build_plan(False, 12)
        plan_keys = {(c["condition"], str(c["rep"])) for c in plan}
        print(f"plan: {len(plan)} cells (no drift refs in this test)\n")

        # ---- phase 1: run, then SIGKILL mid-flight ----------------------
        print("phase 1: run then hard-kill (SIGKILL, no cleanup)")
        rc1, killed_at = launch(td, "never", kill_after=120)
        rows = read_rows(csv_path)
        s = summarise(rows)
        print(f"  child rc={rc1} (negative = killed), rows at kill: {s['rows']}")
        ok &= check(rc1 < 0, "child died by signal, not clean exit")
        ok &= check(s["rows"] >= 100, "rows survived the kill",
                    f"{s['rows']} rows flushed before death")
        ok &= check(s["duplicate_success_keys"] == {},
                    "no duplicates at kill point", str(s["duplicate_success_keys"]))
        killed_keys = {(r["condition"], r["rep"]) for r in rows if r["failed"] == "0"}
        killed_order = [(r["condition"], r["rep"], r["attempt"])
                        for r in rows if r["failed"] == "0"]

        # ---- phase 2: restart, must continue not repeat ------------------
        print("\nphase 2: restart on the same command")
        rc2, _ = launch(td, "never")
        rows2 = read_rows(csv_path)
        s2 = summarise(rows2)
        ok &= check(s2["duplicate_success_keys"] == {},
                    "NO DUPLICATES after restart", str(s2["duplicate_success_keys"]))
        ok &= check(set(k for k in
                        {(r["condition"], r["rep"]) for r in rows2 if r["failed"] == "0"})
                    >= killed_keys,
                    "every cell from before the kill is still present")
        ok &= check(s2["unique_ok"] == len(plan_keys),
                    "NO GAPS: every planned cell has a successful row",
                    f"{s2['unique_ok']}/{len(plan_keys)}")
        ok &= check(rc2 == 0, "restarted run exited cleanly", f"rc={rc2}")

        # The decisive check. "No duplicates" and "no gaps" would both also hold
        # for a driver that silently re-ran everything in a different order, so
        # verify the restart resumed at exactly the first outstanding cell in the
        # plan and that pre-kill cells were never re-executed (attempt stays 1).
        plan_order = [(c["condition"], str(c["rep"])) for c in plan]
        done_at_kill = set(killed_keys)
        expected_next = next(k for k in plan_order if k not in done_at_kill)
        post = [(r["condition"], r["rep"], r["attempt"]) for r in rows2]
        first_new = next(p for p in post if (p[0], p[1]) not in done_at_kill)
        retried_olds = [p for p in post if (p[0], p[1]) in done_at_kill
                        and p[2] != "1"]
        print(f"  evidence: {len(done_at_kill)} cells survived the kill; "
              f"first cell after restart = {first_new[0]} rep={first_new[1]} "
              f"attempt={first_new[2]}")
        print(f"           expected next in plan order     = "
              f"{expected_next[0]} rep={expected_next[1]}")
        ok &= check((first_new[0], first_new[1]) == expected_next,
                    "restart resumed at the first outstanding cell")
        ok &= check(first_new[2] == "1", "resumed cell was not previously attempted")
        ok &= check(retried_olds == [],
                    "cells completed before the kill were NOT re-executed",
                    f"{len(retried_olds)} re-executions")

        # ---- phase 3: fault isolation + retry accounting -----------------
        print("\nphase 3: transient faults (every 5th cell raises)")
        with tempfile.TemporaryDirectory(prefix="fault-test-") as td2:
            c2 = Path(td2) / "results" / "main" / "cells.csv"
            rc3, _ = launch(td2, "periodic")
            rows3 = read_rows(c2)
            s3 = summarise(rows3)
            ok &= check(s3["failed_rows"] > 0,
                        "faulting cells were recorded as failed",
                        f"{s3['failed_rows']} failed rows")
            ok &= check(rc3 == 0,
                        "session SURVIVED the faults (isolation works)", f"rc={rc3}")
            ok &= check(s3["success_rows"] > 0,
                        "healthy cells still recorded alongside failures",
                        f"{s3['success_rows']} ok")

            # retrying the same command must pick the failures back up
            rc4, _ = launch(td2, "never")
            rows4 = read_rows(c2)
            s4 = summarise(rows4)
            plan_keys2 = {(c["condition"], str(c["rep"]))
                          for c in run_matrix.build_plan(False, 12)}
            ok &= check(s4["duplicate_success_keys"] == {},
                        "retries did not duplicate already-good cells",
                        str(s4["duplicate_success_keys"]))
            ok &= check(s4["unique_ok"] == len(plan_keys2),
                        "previously-failed cells were recovered",
                        f"{s4['unique_ok']}/{len(plan_keys2)}")

        # ---- phase 4: a permanently broken cell is abandoned -------------
        print("\nphase 4: permanent fault at rate 700 (never clears)")
        with tempfile.TemporaryDirectory(prefix="perm-test-") as td3:
            c3 = Path(td3) / "results" / "main" / "cells.csv"
            for _ in range(4):
                rc5, _ = launch(td3, "always-on-700")
            rows5 = read_rows(c3)
            s5 = summarise(rows5)
            att = Counter((r["condition"], r["rep"]) for r in rows5
                          if r["rate"] == "700")
            ok &= check(max(att.values()) == 3,
                        "permanently broken cell abandoned after MAX_ATTEMPTS",
                        f"max attempts on a 700 cell = {max(att.values())}")
            ok &= check(s5["exhausted"] > 0, "exhausted cells are counted",
                        f"{s5['exhausted']} exhausted")
            ok &= check(rc5 == 0,
                        "session still completes despite the broken cell")

    print("\n" + ("ALL CHECKS PASSED" if ok else "SOME CHECKS FAILED"))
    return 0 if ok else 1


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--child":
        raise SystemExit(child_run(sys.argv[2], sys.argv[3]))
    raise SystemExit(main())