"""concurrency_gate.py -- prove no arm wedges under concurrent load.

WHY THIS FILE EXISTS. smoke.py and work_equiv.py both drive every arm
SEQUENTIALLY, one request at a time. That is the correct way to check that arms
do identical work, and it is blind to the entire class of failure that only
appears when requests overlap. s3_middleware/sync served 12/12 routes correctly
at concurrency 1 in both gates, then failed 100% of 3600 requests at 600 rps
with a 5 s timeout and ~3% CPU: an unbounded-admission deadlock against the
8-slot sync pool and the 8-token thread limiter. Both pre-flight gates passed it
and the run was launched. This gate is the check that was missing.

It is a gate, not a benchmark. It asserts liveness and correctness under
concurrency -- no wedge, no timeout, no 5xx, and a bounded completion time -- and
deliberately reports no latency percentiles. Anything timing-related here would
be a local-machine artifact (this dev box is not the study host and is not
pinned), and a number that looks like a result but is not one is worse than no
number. Throughput and latency are measured on the study box by run_matrix.

WHAT A WEDGE LOOKS LIKE HERE. A deadlocked server does not crash and does not
slow down gracefully: it accepts connections, holds them, and never answers. So
the assertions are (a) every request completes inside REQUEST_TIMEOUT, (b) no
server errors, and (c) the whole sweep finishes inside WALL_LIMIT. A hung arm
fails (a) first, in wall-clock terms, rather than returning a plausible number.

CONCURRENCY IS THE POINT. CONCURRENCY (64) is deliberately far above POOL (8).
The deadlock needs at least POOL waiters to hold every thread token while
blocking for a connection, so a gate that tested at or below POOL would pass on
the broken arm. Checked explicitly: --assert-fix-catches runs the broken
generator output back through the gate and fails if it is NOT caught.

Usage:
    python concurrency_gate.py                     # gate the current apps/
    python concurrency_gate.py --assert-fix-catches # prove the gate has teeth
"""

from __future__ import annotations

import argparse
import ast
import asyncio
import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent

# Must match the study's POOL, and must exceed it for the deadlock to be
# reachable at all. runner.py pins POOL=8; if that ever changes, this constant
# has to move with it or the gate silently stops testing the failure mode.
CONCURRENCY = 64
POOL = 8
REQUEST_TIMEOUT = 5.0
WALL_LIMIT = 90.0
SETTLE = 1.5

# Mixed on purpose: one public read, one authenticated read, one role-gated read.
# A gate that only hits /health would pass an arm whose authenticated path
# deadlocks, which is exactly the path s3_middleware/sync puts behind middleware.
ROUTES = [
    ("/reviews", "public", 200),
    ("/users/me", "user", 200),
    ("/admin/dashboard", "admin", 200),
]
HEADERS = {
    "public": {},
    "user": {"Authorization": "Bearer user-token"},
    "admin": {"Authorization": "Bearer admin-token"},
}


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def wait_healthy(port: int, proc: subprocess.Popen, timeout: float = 30.0) -> bool:
    """Poll /health over real HTTP.

    Deliberately a real socket rather than an in-process ASGI call: the bug being
    gated lives in anyio's thread limiter and a blocking queue.get() in a worker
    thread, and an in-process transport would not reproduce the token accounting
    the same way.
    """
    import urllib.error
    import urllib.request

    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            return False
        try:
            with urllib.request.urlopen(
                f"http://127.0.0.1:{port}/health", timeout=1.0
            ) as r:
                if r.status == 200:
                    return True
        except (urllib.error.URLError, OSError):
            time.sleep(0.15)
    return False


async def sweep(port: int, rounds: int) -> dict:
    """Fire CONCURRENCY requests at a time until `rounds` complete."""
    import httpx

    ok = 0
    timeouts = 0
    server_errors = 0
    other: dict = {}
    sem = asyncio.Semaphore(CONCURRENCY)
    limits = httpx.Limits(
        max_connections=CONCURRENCY * 2, max_keepalive_connections=CONCURRENCY * 2
    )
    completed = 0
    done = asyncio.Event()

    async with httpx.AsyncClient(
        base_url=f"http://127.0.0.1:{port}",
        timeout=REQUEST_TIMEOUT,
        limits=limits,
    ) as client:

        async def one(i: int) -> None:
            nonlocal ok, timeouts, server_errors, completed
            path, auth, want = ROUTES[i % len(ROUTES)]
            async with sem:
                try:
                    r = await client.get(path, headers=HEADERS[auth])
                    if r.status_code == want:
                        ok += 1
                    elif r.status_code >= 500:
                        server_errors += 1
                    else:
                        other[r.status_code] = other.get(r.status_code, 0) + 1
                except httpx.TimeoutException:
                    timeouts += 1
                except Exception:
                    server_errors += 1
            completed += 1
            if completed >= rounds:
                done.set()

        tasks = [asyncio.create_task(one(i)) for i in range(rounds)]
        try:
            await asyncio.wait_for(done.wait(), timeout=WALL_LIMIT)
        except asyncio.TimeoutError:
            for t in tasks:
                t.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            return {
                "ok": ok, "timeouts": timeouts, "server_errors": server_errors,
                "other": other, "completed": completed, "wedged": True,
            }

    return {
        "ok": ok, "timeouts": timeouts, "server_errors": server_errors,
        "other": other, "completed": completed, "wedged": False,
    }


def gate_arm(pattern: str, model: str, root: Path | None = None) -> dict:
    base = Path(root) if root is not None else HERE
    port = free_port()
    env = dict(os.environ)
    env["PYTHONPATH"] = str(base)
    proc = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", f"apps.{pattern}.{model}.app:app",
         "--host", "127.0.0.1", "--port", str(port), "--workers", "1",
         "--log-level", "warning", "--no-access-log"],
        cwd=str(base), env=env,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    try:
        if not wait_healthy(port, proc):
            return {"arm": f"{pattern}/{model}", "error": "server never became healthy"}
        time.sleep(SETTLE)
        t0 = time.monotonic()
        res = asyncio.run(sweep(port, rounds=CONCURRENCY * 4))
        res["arm"] = f"{pattern}/{model}"
        res["seconds"] = round(time.monotonic() - t0, 2)
        return res
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=5)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--arms", default=None,
                    help="comma-separated pattern/model pairs (default: all 10)")
    ap.add_argument("--assert-fix-catches", action="store_true",
                    help="regenerate the PRE-FIX s3_middleware/sync from git HEAD, "
                         "gate it, and fail unless the gate catches the wedge")
    args = ap.parse_args()

    if args.assert_fix_catches:
        return assert_fix_catches()

    if CONCURRENCY <= POOL:
        print(f"FATAL: CONCURRENCY ({CONCURRENCY}) must exceed POOL ({POOL}); "
              "at or below POOL the deadlock is unreachable and this gate is "
              "vacuous.")
        return 2

    patterns = ["s1_direct", "s2_depends", "s3_middleware", "s4_container", "s4_dishka"]
    models = ["sync", "async"]
    if args.arms:
        pairs = []
        for p in args.arms.split(","):
            pat, _, mod = p.strip().partition("/")
            pairs.append((pat, mod or "sync"))
    else:
        pairs = [(p, m) for p in patterns for m in models]

    print(f"concurrency gate: {CONCURRENCY} concurrent, request timeout "
          f"{REQUEST_TIMEOUT}s, wall limit {WALL_LIMIT}s, POOL={POOL}")
    print(f"(local machine, unpinned -- liveness and correctness only, no timings)")
    print()

    results = []
    failures = []
    for pattern, model in pairs:
        r = gate_arm(pattern, model)
        results.append(r)
        if "error" in r:
            print(f"  {r['arm']:26s} FAIL  {r['error']}")
            failures.append(r["arm"])
            continue
        wedged = r["wedged"]
        bad = wedged or r["timeouts"] or r["server_errors"] or r["other"]
        if bad:
            detail = []
            if wedged:
                detail.append(f"WEDGED: {r['completed']}/{CONCURRENCY*4} "
                              f"completed in {WALL_LIMIT}s")
            if r["timeouts"]:
                detail.append(f"{r['timeouts']} request timeouts")
            if r["server_errors"]:
                detail.append(f"{r['server_errors']} server errors")
            if r["other"]:
                detail.append(f"unexpected statuses {r['other']}")
            print(f"  {r['arm']:26s} FAIL  {'; '.join(detail)}")
            failures.append(r["arm"])
        else:
            print(f"  {r['arm']:26s} PASS  {r['ok']}/{CONCURRENCY*4} ok in "
                  f"{r['seconds']}s")

    print()
    out = HERE / "results" / "concurrency_gate.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(
        {"concurrency": CONCURRENCY, "pool": POOL, "request_timeout": REQUEST_TIMEOUT,
         "results": results, "failures": failures}, indent=2))

    if failures:
        print(f"GATE FAILED -- {len(failures)} arm(s) cannot sustain concurrent load: "
              f"{', '.join(failures)}")
        print("An arm that cannot complete concurrent requests is not measurable at "
              "any rate. Do not launch a run until this passes.")
        return 1
    print(f"GATE PASSED -- all {len(results)} arms completed "
          f"{CONCURRENCY*4} requests at concurrency {CONCURRENCY} with no wedge, "
          "timeout, or server error.")
    print("written", out)
    return 0


def assert_fix_catches() -> int:
    """Prove the gate has teeth by reconstructing the pre-fix arm and REJECTING it.

    A gate that cannot fail is decoration. This rebuilds s3_middleware/sync
    exactly as it was before the admission bound -- by deleting the
    `async with _get_slots():` wrapper and dedenting its body -- into a scratch
    tree, and requires the gate to FAIL it.

    Reconstructing by mutation rather than by running the generator from git HEAD
    is deliberate. HEAD predates the five-arm rename, so that generator emits
    `apps/p3_middleware/sync`, and gating "s3_middleware/sync" there would fail
    because the arm is MISSING -- a false pass that looks exactly like a
    successful reproduction. The mutation below is checked to have actually
    changed the file and to differ from the real arm ONLY in the admission
    bound, so a pass here means the gate rejects that specific defect.
    """
    import shutil
    import tempfile

    tmp = Path(tempfile.mkdtemp(prefix="prefix_s3_"))
    try:
        for name in ("core_read.py", "routes_read.py", "_seed_source.py"):
            shutil.copy(HERE / name, tmp / name)
        shutil.copytree(HERE / "results", tmp / "results", dirs_exist_ok=True)
        shutil.copytree(HERE / "apps", tmp / "apps",
                        ignore=shutil.ignore_patterns("__pycache__"))

        app = tmp / "apps" / "s3_middleware" / "sync" / "app.py"
        src = app.read_text()
        lines = src.splitlines(keepends=True)
        out: list[str] = []
        removed, dedented = 0, 0
        in_body = False
        for ln in lines:
            if ln.strip() == "async with _get_slots():":
                removed += 1
                in_body = True
                continue
            # Dedent ONLY the contiguous block belonging to the wrapper, stopping
            # at the first blank or less-indented line. Dedenting every later
            # 8-space line in the file would also mangle the route handlers below
            # and produce an arm that fails to parse for the wrong reason.
            if in_body:
                if ln.strip() and ln.startswith("        "):
                    out.append(ln[4:])
                    dedented += 1
                    continue
                in_body = False
            out.append(ln)
        app.write_text("".join(out))

        if removed != 1 or dedented != 6:
            print(f"ABORT: the mutation did not apply cleanly "
                  f"(wrapper found {removed}x, {dedented} lines dedented, "
                  "expected 1 and 6). Cannot claim the gate was tested against "
                  "the pre-fix arm.")
            return 1
        try:
            ast.parse(app.read_text())
        except SyntaxError as e:
            print(f"ABORT: mutated app does not parse ({e}).")
            return 1

        print("--- reconstructed PRE-FIX s3_middleware/sync middleware ---")
        body = app.read_text().splitlines()
        for i, ln in enumerate(body):
            if ln.startswith("@app.middleware"):
                for l in body[i:i + 7]:
                    print("   ", l)
                break
        print()

        r = gate_arm("s3_middleware", "sync", root=tmp)
        print("--- gate run against PRE-FIX s3_middleware/sync ---")
        if "error" in r:
            print(f"    {r['error']}")
            print()
            print("ABORT: the reconstructed arm did not start, so the gate was "
                  "never really exercised.")
            return 1
        caught = (r["wedged"] or r["timeouts"] or r["server_errors"]
                  or r["other"])
        print(f"    ok={r['ok']} timeouts={r['timeouts']} "
              f"server_errors={r['server_errors']} wedged={r['wedged']} "
              f"other={r['other']}")
        if caught:
            print()
            print("GATE HAS TEETH: the pre-fix arm was rejected for exactly the "
                  "defect the fix removes. The fix is verified by a check known "
                  "to fail without it.")
            return 0
        print()
        print("*** THE GATE DID NOT CATCH THE KNOWN-BROKEN ARM. ***")
        print("Either the wedge needs more than "
              f"{CONCURRENCY} concurrent requests to appear, or this gate does "
              "not test what it claims. Either way it cannot be trusted to "
              "protect the run.")
        return 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())