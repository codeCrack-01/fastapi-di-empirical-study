"""run_2x2_heavy.py — 2x2 mechanism experiment on a blocking endpoint.

Runs all 8 arms at 2500/3000/3200 req/s with N reps. Each arm's getter does
a blocking SQLite read (SELECT count(*) FROM data on a 1000-row DB), so the
threadpool actually gets stressed.

Usage (single cell, smoke test):
  python run_2x2_heavy.py --arm sync-depends --rate 1000 --reps 1 --port 8799

Usage (full grid):
  python run_2x2_heavy.py --grid --port 8799

Environment:
  APPS_DIR   path to apps_2x2 directory (default: ./apps_2x2)
  K6_PATH    path to k6 binary (default: k6 on PATH)
  PYTHON     python interpreter (default: .venv/bin/python)
  TIER2_FAST=1  shrink windows to 5s/1s/2s, 1 rep (smoke only)
"""
from __future__ import annotations
import argparse, json, os, shutil, subprocess, sys, time, urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
APPS = None  # set in main() from --apps-dir
PY = None    # set in main() from --python
K6 = None    # set in main() from --k6
HARNESS = None  # set in main() from --harness
PORT = 8799
ROUTE = "/data"
SERVER_CORES = os.environ.get("SERVER_CORES", "0,2,4")
K6_CORES = os.environ.get("K6_CORES", "6")
FAST = os.environ.get("TIER2_FAST", "0") == "1"

WARMUP = 5000 if FAST else 10000
WINDOW = 5000 if FAST else 30000
COOLDOWN = 2000 if FAST else 10000
REPS_DEFAULT = 1 if FAST else 10

ARMS = {
    "sync-inline":    "sync-inline",
    "sync-depends":   "sync-depends",
    "async-inline":   "async-inline",
    "async-depends":  "async-depends",
    "wrapper":        "wrapper",
    "limiter-200":    "limiter-200",
    "limiter-1000":   "limiter-1000",
    "limiter-4000":   "limiter-4000",
}

RATES = [2500, 3000, 3200] if not FAST else [1000]


def boot(arm_name, port):
    app_dir = APPS / arm_name
    cmd = []
    if shutil.which("taskset"):
        cmd += ["taskset", "-c", SERVER_CORES]
    cmd += [PY, "-m", "uvicorn", "app:app",
            "--host", "127.0.0.1", "--port", str(port),
            "--workers", "1", "--log-level", "warning", "--no-access-log"]
    log = open(f"server_{arm_name}.log", "a")
    pro = subprocess.Popen(cmd, cwd=app_dir, stdout=log, stderr=subprocess.STDOUT)
    deadline = time.time() + 30
    while time.time() < deadline:
        if pro.poll() is not None:
            raise RuntimeError(f"server exited early rc={pro.returncode}")
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/data", timeout=2)
            return pro
        except Exception:
            time.sleep(0.5)
    pro.kill()
    raise RuntimeError("server did not become ready")


def run_k6(rate, port):
    env = {
        **os.environ,
        "TARGET_URL": f"http://127.0.0.1:{port}",
        "TARGET_PATH": ROUTE,
        "RATE": str(rate),
        "WARMUP_MS": str(WARMUP),
        "WINDOW_MS": str(WINDOW),
        "COOLDOWN_MS": str(COOLDOWN),
    }
    k6cmd = []
    if shutil.which("taskset"):
        k6cmd += ["taskset", "-c", K6_CORES]
    k6cmd += [K6, "run", str(HARNESS)]
    out = subprocess.run(k6cmd, env=env, capture_output=True, text=True,
                         timeout=WARMUP + WINDOW + COOLDOWN + 60)
    return out.stdout + "\n" + out.stderr


def parse_k6(text):
    import json
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("{") and "load_fidelity" in line:
            try:
                d = json.loads(line)
                return {
                    "p99": d.get("window", {}).get("p99"),
                    "p95": d.get("window", {}).get("p95"),
                    "p50": d.get("window", {}).get("p50"),
                    "fidelity": d.get("load_fidelity"),
                    "dropped": d.get("dropped_iterations", 0),
                    "window_errors": d.get("window_errors", 0),
                    "window_requests": d.get("window_requests", 0),
                }
            except json.JSONDecodeError:
                pass
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arm", default="sync-depends", choices=list(ARMS.keys()))
    ap.add_argument("--rate", type=int, default=None)
    ap.add_argument("--reps", type=int, default=REPS_DEFAULT)
    ap.add_argument("--port", type=int, default=PORT)
    ap.add_argument("--grid", action="store_true")
    ap.add_argument("--out", default="results_2x2_heavy.tsv")
    ap.add_argument("--apps-dir", default=None)
    ap.add_argument("--python", default=None)
    ap.add_argument("--k6", default=None)
    ap.add_argument("--harness", default=None)
    args = ap.parse_args()

    global APPS, PY, K6, HARNESS
    # Use /tmp/rf symlink to avoid spaces in paths (Fall'26)
    rf = Path("/tmp/rf")
    if not rf.exists():
        rf = HERE.parent.parent  # fallback to real path
    APPS = Path(args.apps_dir) if args.apps_dir else (rf / "study_c1_4" / "apps_2x2")
    PY = args.python if args.python else str(rf / "study_c1_4" / ".venv" / "bin" / "python")
    K6 = args.k6 if args.k6 else (shutil.which("k6") or "k6")
    HARNESS = Path(args.harness) if args.harness else (rf / "study_c1_4" / "k6" / "harness_t2.js")

    rates = RATES if args.rate is None else [args.rate]
    arms = list(ARMS.keys()) if args.grid else [args.arm]
    results = []
    for arm in arms:
        for rate in rates:
            for rep in range(args.reps):
                print(f"=== {arm} @ {rate} rep {rep+1}/{args.reps} ===", flush=True)
                pro = None
                try:
                    pro = boot(arm, args.port)
                    time.sleep(2)
                    text = run_k6(rate, args.port)
                    parsed = parse_k6(text)
                    p99 = parsed["p99"] if parsed else None
                    fid = parsed["fidelity"] if parsed else None
                    dropped = parsed["dropped"] if parsed else None
                    print(f"  p99={p99} fidelity={fid} dropped={dropped}")
                    results.append({"arm": arm, "rate": rate, "rep": rep+1,
                                    "p99": p99, "fidelity": fid, "dropped": dropped})
                except Exception as e:
                    print(f"  ERROR: {e}")
                    results.append({"arm": arm, "rate": rate, "rep": rep+1,
                                    "p99": None, "error": str(e)})
                finally:
                    if pro:
                        pro.kill(); pro.wait(timeout=20)
                    time.sleep(3)

    with open(args.out, "a") as f:
        for r in results:
            f.write(f"{r['arm']}\t{r['rate']}\t{r['rep']}\t{r.get('p99')}\t{r.get('fidelity')}\t{r.get('dropped',0)}\t{r.get('error','')}\n")
    print(f"\nResults appended to {args.out}")


if __name__ == "__main__":
    main()