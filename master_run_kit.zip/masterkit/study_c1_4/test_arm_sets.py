"""test_arm_sets.py -- the five duplicated arm lists must agree.

The arm set is written out in five places, and it is duplicated deliberately:
analyze.py has to run against a bare cells.csv with no project tree, runner.ARM
resolves an import path, and gen_apps owns the builders. Each copy keeps its
file self-contained. The cost of that choice is that adding an arm to one list
and not the others is silent:

  * a pattern in run_matrix but missing from analyze.PATTERNS is measured and
    never reported, so the study concludes an ordering over four arms and
    presents it as the design;
  * a pattern in gen_apps.PATTERNS with no builder crashes the rebuild AFTER the
    live apps/ directory has already been deleted (that is what happened, and
    test_gen_apps.py exists to prevent a repeat);
  * a pattern missing from runner.ARM's allowlist kills a cell at run time, on
    the box, after hours of cells have already been paid for.

None of these raise locally unless something else happens to notice. Amendment
14 added s4_dishka and had to touch all five; this test exists so the next arm
addition cannot be partial.

It also pins the cell arithmetic. The design has been stated as 768 cells in
three separate places (the run_matrix docstring, status_box.sh's old hard-coded
TOTAL, and the pre-registration), and that number is only correct for FOUR
patterns. With five it is 960, and the study denominator has to be derived from
the design rather than typed in.

Run:  python test_arm_sets.py
"""

from __future__ import annotations

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import analyze  # noqa: E402
import gen_apps  # noqa: E402
import run_matrix  # noqa: E402
import runner  # noqa: E402

# The name each file gives the same arm. A rename that lands in some lists and
# not others is the same class of bug as an addition that lands in some, so the
# mapping is asserted explicitly rather than by set equality alone.
CANONICAL = ["s1_direct", "s2_depends", "s3_middleware", "s4_container", "s4_dishka"]


def check(cond: bool, label: str, detail: str = "") -> bool:
    print(f"  [{'PASS' if cond else 'FAIL'}] {label}" + (f"  {detail}" if detail else ""))
    return cond


def main() -> int:
    ok = True
    arms = gen_apps.PATTERNS

    print("arm lists agree")
    ok &= check(arms == CANONICAL, "gen_apps.PATTERNS is the canonical order",
                str(arms))
    ok &= check(run_matrix.PATTERNS == arms, "run_matrix.PATTERNS", str(run_matrix.PATTERNS))
    ok &= check(analyze.PATTERNS == arms, "analyze.PATTERNS", str(analyze.PATTERNS))
    ok &= check(run_matrix.MODELS == gen_apps.MODELS == analyze.MODELS,
                "MODELS agree",
                f"{gen_apps.MODELS}")

    print("\nmetadata covers every arm")
    ok &= check(set(gen_apps.FAMILY) == set(arms), "FAMILY covers every arm",
                str(sorted(set(arms) - set(gen_apps.FAMILY))))
    ok &= check(set(gen_apps.ARM_INTENT) == set(arms), "ARM_INTENT covers every arm")
    ok &= check(set(gen_apps.BUILDERS) == set(arms), "BUILDERS covers every arm")

    print("\nrunner resolves every arm")
    for p in arms:
        for m in gen_apps.MODELS:
            try:
                path = runner.ARM(p, m)
                ok &= check(path == f"apps.{p}.{m}.app:app", f"ARM({p}, {m})",
                            path)
            except ValueError as exc:
                ok &= check(False, f"ARM({p}, {m})", str(exc))

    print("\nrendered apps exist for every arm")
    for p in arms:
        for m in gen_apps.MODELS:
            f = gen_apps.APPS / p / m / "app.py"
            ok &= check(f.exists(), f"apps/{p}/{m}/app.py exists")

    print("\ncell arithmetic derives from the design, not from a literal")
    cells = run_matrix.build_plan()
    n_arms = len(arms) * len(run_matrix.MODELS)
    pairs = sum(run_matrix.reps_for(run_matrix.band_of(r), False, 12)
                for r in run_matrix.LADDER)
    ok &= check(len(cells) == pairs * n_arms, "build_plan matches rate-rep x arms",
                f"{len(cells)} = {pairs} x {n_arms}")
    ok &= check(len(cells) == 960, "five-arm design is 960 study cells", str(len(cells)))
    ok &= check(len(run_matrix.interleave_drift(cells)) == 965,
                "with 5 drift references", str(len(run_matrix.interleave_drift(cells))))
    # the four-arm number that is still quoted in the pre-registration
    four = [c for c in cells if c["pattern"] != "s4_dishka"]
    ok &= check(len(four) == 768, "four-arm subset is still 768", str(len(four)))

    print("\nreps-per-rate agreement (analyze.want vs run_matrix)")
    for rate in run_matrix.LADDER:
        want_orch = run_matrix.reps_for(run_matrix.band_of(rate), False, 12)
        # the expression analyze.completeness() uses, copied rather than imported
        want_an = 6 if rate <= 500 else (12 if rate <= 900 else 8)
        ok &= check(want_orch == want_an, f"@{rate}",
                    f"orchestrator={want_orch} analyze={want_an}")

    print("\n" + ("ALL CHECKS PASSED" if ok else "SOME CHECKS FAILED"))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
