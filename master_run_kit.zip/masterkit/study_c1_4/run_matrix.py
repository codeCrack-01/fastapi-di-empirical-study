"""run_matrix.py -- Amendment 7 shared offered-load ladder.

Drives the whole grid, or a stage of it. Every arm is offered the *same* fixed
rates, so pattern comparison is a direct observation under identical conditions
rather than a comparison of two independently-derived knees (§4g.2). No knee
probes: the saturation point is derived by interpolating each arm's own curve
afterwards, which removes the 24 ramp searches the knee-relative design needed.

    ladder   200 -> 1200 req/s, step 100, identical for every arm
    reps     allocated per band (see REPS_BY_BAND); 12 in the graded band can
             be topped up to 20 later with no rework, because resume keys on
             (condition, rep) and later reps are simply new pairs
    cells    768 for the four-arm design (Amendment 12); 960 with the fifth arm
             added by Amendment 14 (s4_dishka). The arithmetic is
             (4 flat rates x 6 + 4 graded x 12 + 3 saturated x 8) rate-rep pairs
             = 96, times len(PATTERNS) x len(MODELS) arms.

Ordering is rate-major, rep-minor, arm-innermost, so one (rate, rep) block is one
tight paired block of every arm -- a ~10-minute checkpoint. Host drift
within a block is therefore shared across arms instead of accumulating inside
one. Drift is in any case policed by the reference cells below.

Three properties this driver is built to guarantee:

* **A cell cannot cost more than a cell.** Every cell runs inside its own guard.
  A crash, a port clash, a missing binary or an out-of-memory kill is recorded as
  a *failed* cell and the session continues. Only a mutated database halts the
  run, because that invalidates every later measurement rather than one cell.
* **Nothing measured is lost.** Each row is written and flushed as soon as its
  cell finishes, so a crash costs at most the cell in flight.
* **Restart is exact.** Resume skips (condition, rep) pairs that already have a
  successful row, so a re-run continues at the first outstanding cell with no
  duplicate and no gap. Failed cells are retried, up to MAX_ATTEMPTS, so a
  transient fault does not permanently remove a cell from the design.

    python run_matrix.py --smoke          # harness only, never analysed
    python run_matrix.py --main           # the study ladder
    python run_matrix.py --main --max-cells 32   # first graded-band block
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from runner import (  # noqa: E402
    ARM, WARMUP_S, WINDOW_S, COOLDOWN_S, WORKERS,
    assert_disjoint, run_ramp, sha256_db, LOAD_FIDELITY_FLOOR,
    steal_from_proc_stat, host_facts, PLAN_TYPE, OFFLINE_CORES,
)

PATTERNS = ["s1_direct", "s2_depends", "s3_middleware", "s4_container", "s4_dishka"]
MODELS = ["sync", "async"]

# --- Amendment 7 ladder ------------------------------------------------------
# One shared ladder. Chosen to bracket every archived knee (690-1040) with
# margin; the knees are NOT used to derive these rates.
LADDER = list(range(200, 1201, 100))

# Reps are allocated by band because the bands are not equally informative.
# Every archived knee is >= 690, so the flat band is expected to show all eight
# arms behaving identically -- it is retained to make "identical below
# saturation" an observation, not an assumption, and needs few repetitions to
# show it. The graded band is where saturation starts separating the patterns and
# is where the primary comparison lives. Above it the arms are expected to be
# collapsed and percentiles queue-dominated, so it answers collapsed-vs-intact
# rather than a graded ordering.
FLAT_BAND = (200, 500)
GRADED_BAND = (600, 900)
SATURATED_BAND = (1000, 1200)

# Amendment 12: flat 2 -> 6, saturated 5 -> 8. Both raised on a power
# calculation, not a preference. The exact sign test needs k trim points, and at
# n < 6 the smallest available rejection region already has null size > 0.05, so
# the flat band at n=2 could not run a valid test at all (attainable size 0.50).
# n=6 and n=8 are the smallest counts in each band that admit one. Graded stays
# at 12: its power curve is already good (0.958 at 1.5 sd) and is where the
# primary comparison lives.
REPS_BY_BAND = {"flat": 6, "graded": 12, "saturated": 8}
SMOKE_REPS = 1
GRADED_REPS_MAX = 20  # ceiling for a later top-up without changing the design

# --- host-drift reference cells (amendment 4d, re-anchored for Amendment 7) ---
# Amendment 7 deletes the per-arm knees, so the old anchor -- 25% of this arm's
# own capacity knee -- no longer exists. The reference now sits on the lowest
# rung of the shared ladder: comfortably linear for every arm, which is what
# makes a change in its latency attributable to the host rather than the app.
DRIFT_REF_ARM = "s1_direct/sync"
DRIFT_REF_RATE = 200
DRIFT_REF_COUNT = 5

MAX_ATTEMPTS = 3

FIELDS = [
    "condition", "pattern", "model", "rate", "band", "rep", "attempt",
    "is_drift", "drift_index", "after_cell", "failed", "failure_reason",
    "cell_p50", "cell_p95", "cell_p99", "cell_max", "cell_count",
    "http_p50", "http_p95", "http_p99", "http_max", "http_count",
    "window_p50", "window_p95", "window_p99", "window_mean", "window_max",
    "window_requests", "window_errors", "window_error_rate",
    "load_fidelity", "dropped_iterations", "offered_rate", "achieved_rate",
    "check_fails", "cpu_seconds", "cpu_seconds_per_req", "rss_peak_mb",
    "startup_ms", "db_sha256_before", "db_sha256_after", "db_unchanged",
    "returncode", "timed_out", "wall_seconds",
    # Per-cell host provenance (amendment 14). runner.main() already recorded
    # these, but the study is driven by run_one_cell(), which called run_ramp()
    # directly and wrote none of them -- so the 965-cell dataset could not
    # falsify its own dedicated-host claim. Recorded here so it can.
    "steal_jiffies", "plan_type", "host_cpu_model", "host_physical_cores",
    "host_logical_cpus_online", "host_mem_total", "host_kernel", "offline_cores",
]


def band_of(rate: int) -> str:
    if FLAT_BAND[0] <= rate <= FLAT_BAND[1]:
        return "flat"
    if GRADED_BAND[0] <= rate <= GRADED_BAND[1]:
        return "graded"
    return "saturated"


def reps_for(band: str, smoke: bool, graded_reps: int) -> int:
    if smoke:
        return SMOKE_REPS
    return graded_reps if band == "graded" else REPS_BY_BAND[band]


def parse_rates(spec: str | None) -> list[int] | None:
    """Parse --rates into a validated, ordered subset of LADDER.

    A scope reduction, not a power reduction: reps per band are untouched, so
    whatever rates survive still get their full REPS_BY_BAND allocation. The
    first corrected run uses this to confine the ladder to the graded band
    (600-900), which is where Amendment 7 designated the primary comparison.
    """
    if not spec:
        return None
    out: list[int] = []
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        try:
            v = int(part)
        except ValueError:
            raise SystemExit(f"--rates: {part!r} is not an integer")
        if v not in LADDER:
            raise SystemExit(f"--rates: {v} is not on the ladder {LADDER[0]}-{LADDER[-1]} step 100")
        if v not in out:
            out.append(v)
    if not out:
        raise SystemExit("--rates was given but selected no rates")
    return sorted(out)


def build_plan(smoke: bool = False, graded_reps: int = 12,
               rates: list[int] | None = None) -> list[dict]:
    """rate-major, rep-minor, arm-innermost.

    Deterministic and not shuffled: the resume logic relies on being able to
    recompute the identical order, and arm-innermost placement is what makes a
    block a paired comparison.

    `rates` restricts the ladder without touching reps per band, so a subset run
    is a scope reduction and not a power reduction.
    """
    cells: list[dict] = []
    for rate in (rates if rates is not None else LADDER):
        band = band_of(rate)
        for rep in range(reps_for(band, smoke, graded_reps)):
            for pattern in PATTERNS:
                for model in MODELS:
                    arm = f"{pattern}/{model}"
                    cells.append({
                        "condition": f"{arm}@{rate}",
                        "pattern": pattern, "model": model,
                        "rate": rate, "band": band, "rep": rep,
                    })
    return cells


def make_drift_cell(idx: int, after_cell: int, n_study: int) -> dict:
    """Same arm, same load, every time. Only its position changes, so a trend
    across reference cells is a property of the host, not the application."""
    pattern, model = DRIFT_REF_ARM.split("/")
    return {
        "condition": f"driftref/{DRIFT_REF_ARM}@{DRIFT_REF_RATE}",
        "pattern": pattern, "model": model,
        "rate": DRIFT_REF_RATE, "band": "flat", "rep": idx,
        "is_drift": 1, "drift_index": idx, "after_cell": after_cell,
        "n_study": n_study,
    }


def interleave_drift(cells: list[dict]) -> list[dict]:
    """Splice reference cells at evenly spaced positions, bracketing the session.

    Called after the study order is built, so the study cells keep exactly the
    order build_plan() produced.
    """
    if DRIFT_REF_COUNT <= 0 or not cells:
        return cells
    n = len(cells)
    step = max(1, n // DRIFT_REF_COUNT)
    out: list[dict] = []
    d = 0
    for i, c in enumerate(cells):
        if i % step == 0 and d < DRIFT_REF_COUNT - 1:
            out.append(make_drift_cell(d, i, n))
            d += 1
        out.append(c)
    if d < DRIFT_REF_COUNT:
        out.append(make_drift_cell(d, n, n))
    return out


def check_rate_is_usable(cell: dict) -> None:
    """Fail loudly on a rate k6 cannot run.

    A fractional or non-positive rate is not an error k6 reports usefully: it
    exits during option parsing, the cell records zero requests and a null
    window, and the failure only surfaces later as a mysterious missing result.
    """
    rate = cell.get("rate")
    if not isinstance(rate, int) or rate <= 0:
        raise ValueError(
            f"unusable rate {rate!r} for cell {cell.get('condition')!r} "
            f"(rep {cell.get('rep')})"
        )


def notify(url: str | None, status: str, message: str) -> None:
    """Fire-and-forget progress ping. Never allowed to disturb the run."""
    if not url:
        return
    body = f"{status}: {message}".encode()
    req = urllib.request.Request(url, data=body, method="POST")
    try:
        urllib.request.urlopen(req, timeout=10).close()
    except (urllib.error.URLError, OSError, ValueError) as exc:
        print(f"notify failed (ignored): {exc}", file=sys.stderr)


def read_existing(csv_path: Path) -> tuple[set, dict, int]:
    """Return (keys with a successful row, attempt count per key, failures).

    A key counts as done only if it has a successful row. Failed rows are kept so
    a retry increments the attempt count rather than resetting it, which is what
    stops a permanently-broken cell from being retried forever.
    """
    done: set = set()
    attempts: dict = {}
    if not csv_path.exists():
        return done, attempts, 0
    with open(csv_path) as fh:
        for row in csv.DictReader(fh):
            key = (row["condition"], str(row["rep"]))
            attempts[key] = attempts.get(key, 0) + 1
            if row.get("failed") in ("0", "False", "", None):
                done.add(key)
    return done, attempts, sum(1 for k, n in attempts.items()
                               if k not in done and n >= MAX_ATTEMPTS)


_HOST_CACHE: dict | None = None


def host_facts_cached() -> dict:
    """host_facts() once per process, and never fatal.

    Two reasons this is not a bare call inside run_one_cell(). First, the facts
    are a property of the machine, identical for all 485 cells, so re-reading
    /proc 485 times buys nothing. Second -- and this is a bug this function
    exists to prevent -- host_facts() raises SystemExit when topology.json is
    absent, because sibling_groups() needs it. Called per cell that turned a
    missing metadata file into 485 failed measurements: provenance collection
    silently became the reason no data existed. Host metadata is recorded
    because it is useful, never because a cell may depend on it.
    """
    global _HOST_CACHE
    if _HOST_CACHE is None:
        try:
            _HOST_CACHE = host_facts()
        except BaseException:  # noqa: BLE001 - metadata must not kill a cell
            _HOST_CACHE = {}
    return _HOST_CACHE


def run_one_cell(cell: dict, port0: int, tag: str) -> tuple[dict, dict | None]:
    """Execute one cell under a guard.

    Returns (row, None) on success or (failed_row, exc) if the cell could not be
    completed. The exception is contained here deliberately: a single bad cell
    must not end a session that is otherwise hours from finished.
    """
    safe = re.sub(r"[^A-Za-z0-9._@+-]", "-", cell["condition"])
    t0 = time.time()
    attempt = cell["attempt"]
    try:
        check_rate_is_usable(cell)
        steal_before = steal_from_proc_stat()
        res = run_ramp(ARM(cell["pattern"], cell["model"]), port0,
                       cell["rate"], WINDOW_S, WARMUP_S, COOLDOWN_S,
                       tag=f"{tag}-{safe}-a{attempt}")
        steal_after = steal_from_proc_stat()
        host = host_facts_cached()
        host_steal = ((steal_after - steal_before)
                      if (steal_before is not None and steal_after is not None)
                      else None)
    except BaseException as exc:  # noqa: BLE001 - containment is the point
        row = {f: "" for f in FIELDS}
        row.update({
            "condition": cell["condition"], "pattern": cell["pattern"],
            "model": cell["model"], "rate": cell["rate"],
            "band": cell.get("band", ""), "rep": cell["rep"], "attempt": attempt,
            "is_drift": cell.get("is_drift", 0),
            "drift_index": cell.get("drift_index", ""),
            "after_cell": cell.get("after_cell", ""),
            "failed": 1, "failure_reason": f"{type(exc).__name__}: {exc}"[:200],
            "wall_seconds": round(time.time() - t0, 1),
        })
        return row, exc

    w = res.window or {}
    c = res.cell or {}
    h = res.http or {}
    e = res.extra or {}
    # A cell that hit the wall-clock cap is a FAILED cell, never a slow one.
    failed = 1 if res.timed_out else 0
    reason = "wall-clock cap" if res.timed_out else ""
    row = {
        "condition": cell["condition"], "pattern": cell["pattern"],
        "model": cell["model"], "rate": cell["rate"],
        "band": cell.get("band", ""), "rep": cell["rep"], "attempt": attempt,
        "is_drift": cell.get("is_drift", 0),
        "drift_index": cell.get("drift_index", ""),
        "after_cell": cell.get("after_cell", ""),
        "failed": failed, "failure_reason": reason,
        "cell_p50": c.get("p50"), "cell_p95": c.get("p95"),
        "cell_p99": c.get("p99"), "cell_max": c.get("max"),
        "cell_count": c.get("count"),
        "http_p50": h.get("p50"), "http_p95": h.get("p95"),
        "http_p99": h.get("p99"), "http_max": h.get("max"),
        "http_count": h.get("count"),
        "window_p50": w.get("p50"), "window_p95": w.get("p95"),
        "window_p99": w.get("p99"),
        "window_mean": w.get("mean"), "window_max": w.get("max"),
        "window_requests": e.get("window_requests"),
        "window_errors": e.get("window_errors"),
        "window_error_rate": e.get("window_error_rate"),
        "load_fidelity": res.load_fidelity if res.load_fidelity is not None
                         else res.achieved,
        "dropped_iterations": res.dropped_iterations,
        "offered_rate": res.rate,
        "achieved_rate": round(res.rate * res.achieved, 2) if res.rate else None,
        "check_fails": (res.checks or {}).get("fails"),
        "cpu_seconds": res.cpu_seconds,
        "cpu_seconds_per_req": e.get("cpu_seconds_per_req"),
        "rss_peak_mb": res.rss_peak_mb, "startup_ms": res.startup_ms,
        "db_sha256_before": res.db_sha256_before,
        "db_sha256_after": res.db_sha256_after,
        "db_unchanged": res.db_unchanged, "returncode": res.returncode,
        "timed_out": int(res.timed_out),
        "wall_seconds": round(time.time() - t0, 1),
        "steal_jiffies": host_steal,
        "plan_type": PLAN_TYPE,
        "host_cpu_model": host.get("cpu_model"),
        "host_physical_cores": host.get("physical_cores"),
        "host_logical_cpus_online": host.get("logical_cpus_online"),
        "host_mem_total": host.get("mem_total"),
        "host_kernel": host.get("kernel"),
        "offline_cores": OFFLINE_CORES,
    }
    return row, None


def no_latency_contradiction(row: dict) -> bool:
    """True when a successful cell served the offered load yet produced no
    latency sample -- i.e. the primary metric plumbing is broken.

    A cell that ran, was not cut off by the wall-clock cap, and kept up with the
    offered load must have a p99. If it does not, k6 emitted no usable latency
    trend: a renamed metric, a missing handleSummary key, or a summary that
    never parsed. Without a check this is SILENT -- the row is written with
    http_p99=None, counted successful, and all 568 cells finish "cleanly"
    before analyze.py reports "no data" thirteen hours in.

    Checks http_p99 (the Amendment 11 primary). cell_p99 is checked too: it is
    integer-quantised by k6's Date.now(), so a missing cell_p99 alongside a
    present http_p99 means the lat_cell trend specifically is broken.

Low fidelity is deliberately NOT this condition. A saturated cell at
1200 req/s that completed almost nothing legitimately has no p99: that is
saturation evidence, which the design records rather than filters, and
analyze.py skips such pairs by design. The check fires only on the
contradiction -- fidelity says the load was served, yet there is no latency.

A MISSING fidelity is deliberately not a contradiction either, and that is a
settled decision rather than an oversight (test_resume.py, "fidelity unknown:
no evidence load was served"). The guard asserts that two recorded facts
disagree. With no fidelity reading there is no evidence the load was served, so
there is nothing to contradict; halting a multi-hour session on a cell whose
only defect is that it reported nothing would trade a recoverable gap for an
unrecoverable one. Such a cell is recorded with empty metrics and surfaces in
analyze.py's completeness report, which is the layer that can judge it against
the rest of the design.
    """
    if row.get("failed") != 0:
        return False
    if row.get("load_fidelity") is None or row["load_fidelity"] < LOAD_FIDELITY_FLOOR:
        return False
    return row.get("http_p99") is None or row.get("cell_p99") is None


def main() -> int:
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--smoke", action="store_true", help="1 rep, harness only")
    g.add_argument("--main", action="store_true", help="the study ladder")
    ap.add_argument("--port0", type=int, default=8900)
    ap.add_argument("--only", default=None, help="substring filter on condition")
    ap.add_argument("--rates", default=None,
                    help="comma-separated subset of the ladder, e.g. 600,700,800,900. "
                         "Scope reduction only: reps per band are unchanged, and the "
                         "drift references stay enabled. Mutually exclusive with --only.")
    ap.add_argument("--max-cells", type=int, default=0,
                    help="stop after N cells this invocation (staged commitment)")
    ap.add_argument("--graded-reps", type=int, default=12,
                    help=f"reps in the graded band (max {GRADED_REPS_MAX})")
    ap.add_argument("--no-drift", action="store_true",
                    help="disable the host-drift reference cells")
    ap.add_argument("--notify-url", default=os.environ.get("SYNCASYNC_NOTIFY_URL"),
                    help="ntfy endpoint for progress pings")
    ap.add_argument("--notify-every", type=int, default=10)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    assert_disjoint()

    if args.graded_reps > GRADED_REPS_MAX:
        raise SystemExit(f"--graded-reps above the {GRADED_REPS_MAX} design ceiling")
    if args.graded_reps < REPS_BY_BAND["graded"]:
        raise SystemExit(
            f"--graded-reps {args.graded_reps} is below the preregistered "
            f"{REPS_BY_BAND['graded']}; lowering it needs a dated amendment"
        )

    if args.only and args.rates:
        raise SystemExit("--only and --rates are mutually exclusive")

    rates = parse_rates(args.rates)

    smoke = args.smoke
    tag = "smoke" if smoke else "main"
    outdir = HERE / "results" / tag
    outdir.mkdir(parents=True, exist_ok=True)

    cells = build_plan(smoke, args.graded_reps, rates)
    if args.only:
        cells = [c for c in cells if args.only in c["condition"]]
    n_study = len(cells)
    if not args.no_drift and not args.only:
        cells = interleave_drift(cells)

    by_band: dict[str, int] = {}
    for c in cells:
        if not c.get("is_drift"):
            by_band[c["band"]] = by_band.get(c["band"], 0) + 1
    shown = (f"{rates[0]}-{rates[-1]}" if rates and len(rates) > 1
             else (str(rates[0]) if rates else f"{LADDER[0]}-{LADDER[-1]}"))
    print(f"run  tag={tag}  rates={shown} step100  "
          f"graded_reps={args.graded_reps}")
    print(f"    study_cells={n_study} total={len(cells)} bands={by_band}")
    print(f"out  {outdir}")
    if smoke:
        print("NOTE: smoke data is written for provenance and NEVER analysed")

    if args.dry_run:
        for c in cells:
            print(f"  {c['condition']:34s} rep={c['rep']:2d} rate={c['rate']:5d} "
                  f"band={c.get('band','-'):<9}"
                  f"{'DRIFT-REF' if c.get('is_drift') else ''}")
        return 0

    # design_cells is the FULL ladder with no --only filter; study_cells is what
    # THIS invocation is running. They are equal except for a staged commitment,
    # and status_box.sh reads design_cells for its denominator, because a staged
    # --only run would otherwise overwrite the denominator with its own subset
    # size and the box would report 100% while most of the design was unrun.
    (outdir / "plan.json").write_text(json.dumps({
        "design": "amendment-7 shared ladder",
        "ladder": rates if rates is not None else LADDER,
        "ladder_full": LADDER,
        "rates_scope_reduction": rates, "bands": {"flat": list(FLAT_BAND),
                                    "graded": list(GRADED_BAND),
                                    "saturated": list(SATURATED_BAND)},
        "reps": {**REPS_BY_BAND, "graded": args.graded_reps},
        "ordering": "rate-major, rep-minor, arm-innermost",
        "arms": PATTERNS, "models": MODELS,
        "smoke": smoke,
        "design_cells": len(build_plan(smoke, args.graded_reps, rates)),
        "study_cells": n_study,
        "only_filter": args.only,
        "drift_ref": {"arm": DRIFT_REF_ARM, "rate": DRIFT_REF_RATE,
                      "count": DRIFT_REF_COUNT, "enabled": not args.no_drift,
                      "role": "host-drift diagnostic only; excluded from analysis"},
        "workers": WORKERS, "warmup_s": WARMUP_S, "window_s": WINDOW_S,
        "cooldown_s": COOLDOWN_S,
    }, indent=2))

    csv_path = outdir / "cells.csv"
    done, attempts, exhausted = read_existing(csv_path)
    if done:
        print(f"resume: {len(done)} successful cells already recorded, "
              f"{exhausted} permanently failed after {MAX_ATTEMPTS} attempts")

    fh = open(csv_path, "a", newline="")
    writer = csv.DictWriter(fh, fieldnames=FIELDS)
    if not attempts:
        writer.writeheader()
        fh.flush()

    db_before_first = sha256_db()
    t_start = time.time()
    n = ok = bad = skipped = 0
    try:
        for cell in cells:
            key = (cell["condition"], str(cell["rep"]))
            if key in done:
                skipped += 1
                continue
            if attempts.get(key, 0) >= MAX_ATTEMPTS:
                print(f"  SKIP {key} exhausted {MAX_ATTEMPTS} attempts",
                      file=sys.stderr)
                skipped += 1
                continue
            cell["attempt"] = attempts.get(key, 0) + 1

            row, exc = run_one_cell(cell, args.port0, tag)
            writer.writerow(row)
            fh.flush()
            attempts[key] = cell["attempt"]
            n += 1

            # A successful cell that served the offered load but returned no
            # latency sample is a contradiction, not a data point: k6 ran, the
            # server answered, and the primary trend came back empty. That is
            # the signature of broken metric plumbing (a renamed trend, a
            # missing handleSummary key), and it is SILENT -- without this
            # check the row is written with cell_p99=None, marked successful,
            # and every one of the 568 cells completes "cleanly" before
            # analyze.py reports "no data" thirteen hours later.
            #
            # Low fidelity is deliberately NOT this condition. A saturated cell
            # at 1200 req/s that completed almost nothing legitimately has no
            # p99 -- that is saturation evidence, which the design records
            # rather than filters, and analyze.py skips such pairs by design.
            # The guard fires only on the contradiction: fidelity says the load
            # was served, yet there is no latency.
            #
            # Hard stop, never a retry: the cause is deterministic, so the 3
            # attempts in MAX_ATTEMPTS would burn three cells' worth of the
            # timing budget to produce the same empty trend. Same rationale as
            # the database-mutation halt below.
            if no_latency_contradiction(row):
                print("FATAL: cell served the offered load but produced no "
                      "latency sample (primary metric plumbing is broken); "
                      f"stopping at {cell['condition']} rep={cell['rep']} "
                      f"fidelity={row['load_fidelity']}", file=sys.stderr)
                notify(args.notify_url, "failed",
                       f"no latency sample at {cell['condition']} "
                       f"(fidelity {row['load_fidelity']:.3f}); run halted")
                return 3

            if row["failed"]:
                bad += 1
            else:
                ok += 1
                done.add(key)

            # A mutated database is not a per-cell fault: it invalidates every
            # later measurement, so it halts the run rather than being skipped.
            if row["failed"] == 0 and not row["db_unchanged"]:
                print("FATAL: database hash changed mid-run; stopping",
                      file=sys.stderr)
                notify(args.notify_url, "failed",
                       f"db hash changed at {cell['condition']}; run halted")
                return 2

            if row["is_drift"] or n == 1 or n % max(1, args.notify_every) == 0:
                el = time.time() - t_start
                eta = (el / n) * (len(cells) - n) if n else 0
                if row["is_drift"]:
                    print(f"  [{n}/{len(cells)}] DRIFT-REF #{row['drift_index']} "
                          f"after_cell={row['after_cell']} p99={row['http_p99']}ms "
                          f"fid={row['load_fidelity']} elapsed={el / 60:.1f}m",
                          flush=True)
                else:
                    print(f"  [{n}/{len(cells)}] {row['condition']} "
                          f"p99={row['http_p99']}ms fid={row['load_fidelity']} "
                          f"{'FAILED ' if row['failed'] else ''}"
                          f"elapsed={el / 60:.1f}m eta={eta / 60:.0f}m", flush=True)
                notify(args.notify_url, "progress",
                       f"{n}/{len(cells)} {row['condition']} "
                       f"p99={row['http_p99']}ms fid={row['load_fidelity']} "
                       f"elapsed={el / 60:.0f}m eta={eta / 60:.0f}m")

            if args.max_cells and n >= args.max_cells:
                print(f"stopping at --max-cells {n}; "
                      f"{len(done)} of {len(cells)} cells recorded", flush=True)
                notify(args.notify_url, "completed",
                       f"staged stop at {n} cells, {len(done)}/{len(cells)} done")
                break
    finally:
        fh.close()

    db_after = sha256_db()
    print(f"\ndone  ran={n} ok={ok} failed={bad} skipped_already_done={skipped} "
          f"in {(time.time() - t_start) / 3600:.2f}h")
    print(f"db    {db_before_first[:16]} -> {db_after[:16]} "
          f"unchanged={db_before_first == db_after}")
    print(f"csv   {csv_path}")

    # Fault isolation is supposed to keep a bad cell from ending the session. The
    # cost of that is that a *systemic* fault -- a coding error, a missing binary,
    # a broken venv -- fails every cell identically and quietly, which would
    # otherwise leave a "successful" run holding nothing usable. A run in which
    # almost nothing succeeded is a failed run, and must not report success.
    if ok == 0 and n > 0:
        print("FATAL: every attempted cell failed. This is a harness or "
              "environment fault, not a measurement. Not reporting success.",
              file=sys.stderr)
        notify(args.notify_url, "failed",
               f"all {n} attempted cells failed; environment/harness fault")
        return 3
    if bad >= 20 and bad >= 0.5 * n:
        print(f"FATAL: {bad}/{n} attempted cells failed. Failure rate too high "
              f"to treat as isolated faults. Aborting.", file=sys.stderr)
        notify(args.notify_url, "failed",
               f"{bad}/{n} cells failed; aborting rather than continuing")
        return 3
    if bad:
        notify(args.notify_url, "needs_input",
               f"{bad} cell(s) failed; re-run the same command to retry them")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())